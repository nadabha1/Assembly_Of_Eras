#include "menu.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>


//INIT
void init_all_menu(menu *B,input *Input)
{
	init_ouverture(B);
	initmusic();
	initialiser_background_menu(B);
	init_input(Input);
	initialiser_button_menu(B);
	init_sound(B);
	initialiser_background_play(B);
	initialiser_background_settings_credit(B);
	initialiser_volume(B);
	initialiser_full_or_windowed_screen(B);
	initText(B);
	init_fullscreen_back(B);
	B->buttonaffich=0;
	B->buttonchoix=0;
	B->arrowpos=0;
	B->soundcontrol=0;
	B->menu=-1;
	B->affichtest=0;
	B->affonetime=0;
	B->affichbackmenuonetime=0;


}

void init_ouverture(menu *m)
{
	m->ouverture_texte=IMG_Load("RES/Menu/animation ouverture/LOGO OUVERTURE.png");
	m->ouverture_back=IMG_Load("RES/Menu/animation ouverture/black back.png");
	m->ouverture=0;
}


void initText(menu *m)
{
m->c.pos_credit1.x=550;
m->c.pos_credit2.x=700;
m->c.pos_credit3.x=600;
m->c.pos_credit4.x=600;
m->c.pos_credit4_5.x=600;
m->c.pos_credit5.x=600;
m->c.pos_credit6.x=600;
m->c.pos_credit7.x=600;
m->c.pos_credit8.x=600;

m->c.pos_credit1.y=320;
m->c.pos_credit2.y=320;
m->c.pos_credit3.y=370;
m->c.pos_credit4.y=420;
m->c.pos_credit4_5.y=470;
m->c.pos_credit5.y=520;
m->c.pos_credit6.y=570;


m->c.creditColor.r=255;
m->c.creditColor.g=255;
m->c.creditColor.b=255;
m->c.font=TTF_OpenFont("RES/Font/1.ttf",60);
strcpy(m->c.name1,"Team");
strcpy(m->c.name2,"Members");
strcpy(m->c.name3,"Mahdi Koubaa");
strcpy(m->c.name4,"Ahmed Trabelsi");
strcpy(m->c.name4_5,"Nada Belhadjamor");
strcpy(m->c.name5,"Mohamed Ali Hamraoui");
strcpy(m->c.name6,"Aziz Ben Ajmia");
m->c.texte_credit1=TTF_RenderText_Blended(m->c.font,m->c.name1,m->c.creditColor);
m->c.texte_credit2=TTF_RenderText_Blended(m->c.font,m->c.name2,m->c.creditColor);
m->c.texte_credit3=TTF_RenderText_Blended(m->c.font,m->c.name3,m->c.creditColor);
m->c.texte_credit4=TTF_RenderText_Blended(m->c.font,m->c.name4,m->c.creditColor);
m->c.texte_credit4_5=TTF_RenderText_Blended(m->c.font,m->c.name4_5,m->c.creditColor);
m->c.texte_credit5=TTF_RenderText_Blended(m->c.font,m->c.name5,m->c.creditColor);
m->c.texte_credit6=TTF_RenderText_Blended(m->c.font,m->c.name6,m->c.creditColor);

}

//--------------
void init_sound(menu *B)
{
	B->sound=Mix_LoadWAV("RES/Menu/sound/Click De  Souris.wav");
}
//--------------
void initmusic()
{
	Mix_Music *music;
	if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)

		{printf("NO AUDIO %s\n",Mix_GetError());}

 
	Mix_VolumeMusic(20);
	music = Mix_LoadMUS("RES/menu son.mp3"); //load the music 
	
	Mix_PlayMusic(music,-1); //play music 
}

//-------------

void init_fullscreen_back(menu *m)
{
	m->f.fullscreen_back=IMG_Load("RES/Menu/Fullscreen/Fullscreen back.gif");

	m->f.pos_fullscreen_back.x=0;
	m->f.pos_fullscreen_back.y=0;
	
	m->f.affiche_fullscreen=0;
	m->f.x=0;
	m->f.y=0;

}

void initialiser_background_menu(menu *m)
{
	int i;
	char filename[43];
	for(i=0;i<4;i++)
	{
		sprintf(filename,"RES/Menu/menu anim/menu %d.png",i); 
		m->menu_back[i] = IMG_Load(filename);
	}

	m->pos_menu_back.x=0;
	m->pos_menu_back.y=0;
	m->pos_menu_back.w=0;
	m->pos_menu_back.h=0;

	m->conteur1=0;
	m->conteur2=0;


	
}

void initialiser_volume(menu *m)  		
{
m->s.img_soundminus= IMG_Load("RES/Menu/Settings/soundminus.png");
m->s.img_soundplus= IMG_Load("RES/Menu/Settings/soundplus.png");


m->s.pos_soundminus.x=579;
m->s.pos_soundminus.y=355;
m->s.pos_soundminus.w=88;
m->s.pos_soundminus.h=70;

m->s.pos_soundplus.x=906;
m->s.pos_soundplus.y=355;
m->s.pos_soundplus.w=88;
m->s.pos_soundplus.h=70;

m->s.img_soundon= IMG_Load("RES/Menu/Settings/soundon.png");
m->s.img_soundoff= IMG_Load("RES/Menu/Settings/soundoff.png");


m->s.pos_soundon.x=542;
m->s.pos_soundon.y=431;
m->s.pos_soundon.w=88;
m->s.pos_soundon.h=70;

m->s2.img_curseurvol= IMG_Load("RES/Menu/Settings/sound curser.png");

m->s2.pos_curseurvol.x=685;
m->s2.pos_curseurvol.y=373;
m->s2.pos_curseurvol.w=10;
m->s2.pos_curseurvol.h=30;

m->s.volu=20;
m->s.Vol=20;
m->s.testvol=0;


}

void initialiser_full_or_windowed_screen(menu *m)  	
{
	m->s2.button_fullscreenon= IMG_Load("RES/Menu/Settings/Fullscreenon.png");
	m->s2.button_fullscreenoff= IMG_Load("RES/Menu/Settings/Fullscreenoff.png");

	m->s2.pos_button_fullscreen.x=581;
	m->s2.pos_button_fullscreen.y=538;
	m->s2.pos_button_fullscreen.w=83;
	m->s2.pos_button_fullscreen.h=67;

	m->s2.button_windowedon= IMG_Load("RES/Menu/Settings/Windowed on.png");
	m->s2.button_windowedoff= IMG_Load("RES/Menu/Settings/Windowed off.png");

	m->s2.pos_button_windowed.x=905;
	m->s2.pos_button_windowed.y=538;
	m->s2.pos_button_windowed.w=83;
	m->s2.pos_button_windowed.h=67;
	
	m->s2.button_back=IMG_Load("RES/Menu/Settings/Back.png");

	m->s2.pos_button_back.x=387;
	m->s2.pos_button_back.y=236;
	m->s2.pos_button_back.w=179;
	m->s2.pos_button_back.h=76;

	m->s2.mode=0;
	m->s2.affiche=0;
}

void initialiser_background_play(menu *m)//here
{
	m->p.Load_back=IMG_Load("RES/Menu/menu play/Loadgame menu.png");
	m->p.multi_back=IMG_Load("RES/Menu/menu play/multiplayers menu.png");
	m->p.affich_Load_multi_onetime=0;
	m->p.player_nbr=0;


}

void initialiser_background_settings_credit(menu *B)
{
	(*B).credit_back=IMG_Load("RES/Menu/credit/menu credit.png");
	(*B).s.settings_back=IMG_Load("RES/Menu/Settings/settings back.png");

	(*B).s.pos_settings.x=375;
	(*B).s.pos_settings.y=200;
	(*B).s.pos_settings.w=873;
	(*B).s.pos_settings.h=482;
	(*B).pos_credit.x=375;
	(*B).pos_credit.y=200;
	(*B).pos_credit.w=873;
	(*B).pos_credit.h=482;

}

void initialiser_button_menu(menu *B)
{
	(*B).button_play_off=IMG_Load("RES/Menu/Buttons/PLAY.png");
	(*B).button_play_on=IMG_Load("RES/Menu/Buttons/PLAY1.png");
	(*B).pos_button_play.x=200;
	(*B).pos_button_play.y=360;
	(*B).pos_button_play.w=311;
	(*B).pos_button_play.h=135;

	(*B).button_settings_off=IMG_Load("RES/Menu/Buttons/OPTIONS.png");
	(*B).button_settings_on=IMG_Load("RES/Menu/Buttons/OPTIONS1.png");
	(*B).pos_button_settings.x=200;
	(*B).pos_button_settings.y=430;
	(*B).pos_button_settings.w=311;
	(*B).pos_button_settings.h=135;

	(*B).button_credit_off=IMG_Load("RES/Menu/Buttons/CREDIT.png");
	(*B).button_credit_on=IMG_Load("RES/Menu/Buttons/CREDIT1.png");
	(*B).pos_button_credit.x=200;
	(*B).pos_button_credit.y=500;
	(*B).pos_button_credit.w=311;
	(*B).pos_button_credit.h=135;

	(*B).button_exit_off=IMG_Load("RES/Menu/Buttons/EXIT.png");
	(*B).button_exit_on=IMG_Load("RES/Menu/Buttons/EXIT1.png");
	(*B).pos_button_exit.x=200;
	(*B).pos_button_exit.y=570;
	(*B).pos_button_exit.w=311;
	(*B).pos_button_exit.h=135;

}
//AFFICHAGE
void affiche_Menu(menu *m, SDL_Surface* screen)
{
	affiche_animation_ouverture(m,screen);
	affiche_MenuBackground(m,screen);
	affiche_button_Menu(m,screen);
	affiche_playBackground(m,screen);
	affiche_button_settings(m,screen);
	affiche_creditBackground(m,screen);
	affiche_fullscreen(m,screen);
	affmenumulti(m,screen);
}

void affiche_animation_ouverture(menu *m, SDL_Surface* screen)//here
{
	if(m->ouverture<200)
		{
		 SDL_BlitSurface(m->ouverture_texte,NULL,screen,&m->pos_menu_back);
		 m->ouverture++;
		}
	else if (m->ouverture<=250)
		{
		 SDL_BlitSurface(m->ouverture_back,NULL,screen,&m->pos_menu_back);
		 m->ouverture++;
		}
	if(m->ouverture==249)
		{m->menu=0;}
	
}

void affiche_menu_animer(menu *m,SDL_Surface* screen)
{
	if(m->conteur1==3)
		m->conteur1=0;
	else if(m->conteur2==25)
		{
		 m->conteur1++;
		 m->conteur2=0;
		}
	else
		m->conteur2++;
	SDL_BlitSurface(m->menu_back[m->conteur1],NULL,screen,&m->pos_menu_back);
	
	
		
	
}

void affiche_MenuBackground(menu *m, SDL_Surface* screen)
{
	if((m->buttonaffich==0)&&(m->menu==0))
	{
		m->affichtest=0;
		
		affiche_menu_animer(m,screen);
	}
}

void affiche_playBackground(menu *m, SDL_Surface* screen)
{
	if(m->menu==1)
	{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->p.Load_back,NULL,screen,&m->s.pos_settings);//here
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);
		
	}
}

void affiche_settingsBackground(menu *m, SDL_Surface* screen)
{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->s.settings_back,NULL,screen,&m->s.pos_settings);
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);
		
}

void affiche_volume(menu *m, SDL_Surface* screen)
{
	int i;
	if(m->s.testvol!=m->s.volu)
	{
	if(m->f.x==150)
	{
		i=150;
	}
	else
		i=0;
	if(m->s.volu==0)
		{m->s2.pos_curseurvol.x=685+i;
		
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==20)
		{m->s2.pos_curseurvol.x=725+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==40)
		{m->s2.pos_curseurvol.x=765+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==60)
		{m->s2.pos_curseurvol.x=800+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==80)
		{m->s2.pos_curseurvol.x=840+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==100)
		{m->s2.pos_curseurvol.x=880+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	m->s.testvol=m->s.volu;
	m->s2.affiche=0;
	}

		SDL_BlitSurface(m->s.img_soundminus,NULL,screen,&m->s.pos_soundminus);
		SDL_BlitSurface(m->s.img_soundplus,NULL,screen,&m->s.pos_soundplus);
	if (m->s.volu>0)
		{
		 SDL_BlitSurface(m->s.img_soundon,NULL,screen,&m->s.pos_soundon);
		}
	else
		{
		 SDL_BlitSurface(m->s.img_soundoff,NULL,screen,&m->s.pos_soundon);
		}
}

void affiche_mode(menu *m, SDL_Surface* screen)
{

 if(m->s2.mode==0)
	{
	 SDL_BlitSurface(m->s2.button_windowedon,NULL,screen,&m->s2.pos_button_windowed);
	 SDL_BlitSurface(m->s2.button_fullscreenoff,NULL,screen,&m->s2.pos_button_fullscreen);
	}
 else if(m->s2.mode==1)
	{
	 SDL_BlitSurface(m->s2.button_windowedoff,NULL,screen,&m->s2.pos_button_windowed);
	 SDL_BlitSurface(m->s2.button_fullscreenon,NULL,screen,&m->s2.pos_button_fullscreen);
	}

}


void affiche_button_settings(menu *m, SDL_Surface* screen)
{
	if(m->menu==2)
	{
		if(m->s2.affiche==0)
		{
			m->s2.affiche=1;
			affiche_volume(m,screen);
			affiche_mode(m,screen);
		}
		
	}
}

void affiche_creditBackground(menu *m, SDL_Surface* screen)
{
	if((m->menu==3))
	{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->credit_back,NULL,screen,&m->s.pos_settings);
		SDL_BlitSurface(m->c.texte_credit1,NULL,screen,&m->c.pos_credit1);
		SDL_BlitSurface(m->c.texte_credit2,NULL,screen,&m->c.pos_credit2);
		SDL_BlitSurface(m->c.texte_credit3,NULL,screen,&m->c.pos_credit3);
		SDL_BlitSurface(m->c.texte_credit4,NULL,screen,&m->c.pos_credit4);
		SDL_BlitSurface(m->c.texte_credit4_5,NULL,screen,&m->c.pos_credit4_5);
		SDL_BlitSurface(m->c.texte_credit5,NULL,screen,&m->c.pos_credit5);
		SDL_BlitSurface(m->c.texte_credit6,NULL,screen,&m->c.pos_credit6);
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);
		
	}
}


void affmenumulti(menu *m,SDL_Surface* screen)
{
	if((m->menu==5))
	{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->p.multi_back,NULL,screen,&m->s.pos_settings);
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);	
	}
	
}

void affiche_button_Menu(menu *m, SDL_Surface* screen)
{	
	if(m->menu==0)
	{
	
			affiche_menu_animer(m,screen);
			SDL_BlitSurface(m->button_play_off,NULL,screen,&m->pos_button_play);
			SDL_BlitSurface(m->button_exit_off,NULL,screen,&m->pos_button_exit);
			SDL_BlitSurface(m->button_credit_off,NULL,screen,&m->pos_button_credit);
			SDL_BlitSurface(m->button_settings_off,NULL,screen,&m->pos_button_settings);
		
	if(m->buttonchoix==1)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_play_on,NULL,screen,&m->pos_button_play);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	else
	if(m->buttonchoix==2)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_settings_on,NULL,screen,&m->pos_button_settings);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	else
	if(m->buttonchoix==3)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_credit_on,NULL,screen,&m->pos_button_credit);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	else
	if(m->buttonchoix==4)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_exit_on,NULL,screen,&m->pos_button_exit);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	if(m->arrowpos==1)
		{
			SDL_BlitSurface(m->button_play_on,NULL,screen,&m->pos_button_play);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}
	else
	if(m->arrowpos==2)
		{
			SDL_BlitSurface(m->button_settings_on,NULL,screen,&m->pos_button_settings);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}
	else
	if(m->arrowpos==3)
		{
			SDL_BlitSurface(m->button_credit_on,NULL,screen,&m->pos_button_credit);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}
	else
	if(m->arrowpos==4)
		{
			
			SDL_BlitSurface(m->button_exit_on,NULL,screen,&m->pos_button_exit);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}

	}		
	
}

void affiche_fullscreen(menu *m,SDL_Surface* screen)
{
	if((m->f.affiche_fullscreen==0)&&(m->s2.mode==1))
	{
		SDL_BlitSurface(m->f.fullscreen_back,NULL,screen,&m->f.pos_fullscreen_back);
		m->f.affiche_fullscreen=1;
	}
}

//MAJ
void menu_multiplayer(menu *m,input *inp)//here
{
	if(pos_mouse(*inp,603+m->f.x,1000+m->f.x,290+m->f.y,423+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->p.player_nbr=1;
		m->menu=-1;
	}
	if(pos_mouse(*inp,603+m->f.x,1000+m->f.x,476+m->f.y,609+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->p.player_nbr=2;
		m->menu=-1;
	}
}

void menuLoad(menu *m,input *inp)//here
{
	if(pos_mouse(*inp,641+m->f.x,947+m->f.x,290+m->f.y,423+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->menu=5;
		m->p.affich_Load_multi_onetime=0;
	}
	if(pos_mouse(*inp,641+m->f.x,947+m->f.x,476+m->f.y,609+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->menu=5;
		m->p.affich_Load_multi_onetime=0;
	}
}

void Volume(menu *m,input input_rep)
{
	
	if((input_rep.keys.n==1)||(pos_mouse(input_rep,m->s.pos_soundminus.x,m->s.pos_soundminus.x+m->s.pos_soundminus.w,m->s.pos_soundminus.y,m->s.pos_soundminus.y+m->s.pos_soundminus.h)))
		{if(m->s.volu>0)
     		     {m->s.volu=m->s.volu-20;
       		    Mix_VolumeMusic(m->s.volu);
			SDL_Delay(200);}
			}
	if((input_rep.keys.b==1)||(pos_mouse(input_rep,m->s.pos_soundplus.x,m->s.pos_soundplus.x+m->s.pos_soundplus.w,m->s.pos_soundplus.y,m->s.pos_soundplus.y+m->s.pos_soundplus.h)))
		{ if(m->s.volu<100)
     		     {m->s.volu=m->s.volu+20;
       		    Mix_VolumeMusic(m->s.volu);
			SDL_Delay(200);}
			}
	if((input_rep.keys.m==1)||(pos_mouse(input_rep,m->s.pos_soundon.x,m->s.pos_soundon.x+m->s.pos_soundon.w,m->s.pos_soundon.y,m->s.pos_soundon.y+m->s.pos_soundon.h)))
		{if(m->s.volu>0)
     		     {Mix_VolumeMusic(0);
		      m->s.Vol=m->s.volu;
		      m->s.volu=0;
			SDL_Delay(200);}
		   else 
     		     {m->s.volu=m->s.Vol;
       		    Mix_VolumeMusic(m->s.volu);
			SDL_Delay(200);
			}
			}
}

void fullscreen_windowed(menu *m,input inp,SDL_Surface* screen)
{
	if((pos_mouse(inp,m->s2.pos_button_windowed.x,m->s2.pos_button_windowed.x+m->s2.pos_button_windowed.w,m->s2.pos_button_windowed.y,m->s2.pos_button_windowed.y+m->s2.pos_button_windowed.h)==1)&&(m->s2.mode==1))
		{
			m->s2.mode=0;
			m->affichtest=0;
			screen = SDL_SetVideoMode(1620, 880,32, SDL_HWSURFACE| SDL_DOUBLEBUF);
			m->f.affiche_fullscreen=0;
			m->f.x=-150;
			m->f.y=-100;
			
			m->c.pos_credit1.x=m->c.pos_credit1.x+m->f.x;
			m->c.pos_credit2.x=m->c.pos_credit2.x+m->f.x;
			m->c.pos_credit3.x=m->c.pos_credit3.x+m->f.x;
			m->c.pos_credit4.x=m->c.pos_credit4.x+m->f.x;
			m->c.pos_credit4_5.x=m->c.pos_credit4_5.x+m->f.x;
			m->c.pos_credit5.x=m->c.pos_credit5.x+m->f.x;
			m->c.pos_credit6.x=m->c.pos_credit6.x+m->f.x;
			
			m->c.pos_credit1.y=m->c.pos_credit1.y+m->f.y;
			m->c.pos_credit2.y=m->c.pos_credit2.y+m->f.y;
			m->c.pos_credit3.y=m->c.pos_credit3.y+m->f.y;
			m->c.pos_credit4.y=m->c.pos_credit4.y+m->f.y;
			m->c.pos_credit4_5.y=m->c.pos_credit4_5.y+m->f.y;
			m->c.pos_credit5.y=m->c.pos_credit5.y+m->f.y;
			m->c.pos_credit6.y=m->c.pos_credit6.y+m->f.y;
			
			m->s.pos_soundminus.x=m->s.pos_soundminus.x+m->f.x;
			m->s.pos_soundminus.y=m->s.pos_soundminus.y+m->f.y;

			m->s.pos_soundplus.x=m->s.pos_soundplus.x+m->f.x;
			m->s.pos_soundplus.y=m->s.pos_soundplus.y+m->f.y;

			m->s.pos_soundon.x=m->s.pos_soundon.x+m->f.x;
			m->s.pos_soundon.y=m->s.pos_soundon.y+m->f.y;

			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;//here
			m->s2.pos_curseurvol.y=m->s2.pos_curseurvol.y+m->f.y;
			
			m->s2.pos_button_fullscreen.x=m->s2.pos_button_fullscreen.x+m->f.x;
			m->s2.pos_button_fullscreen.y=m->s2.pos_button_fullscreen.y+m->f.y;

			m->s2.pos_button_windowed.x=m->s2.pos_button_windowed.x+m->f.x;
			m->s2.pos_button_windowed.y=m->s2.pos_button_windowed.y+m->f.y;
		
			m->s2.pos_button_back.x=m->s2.pos_button_back.x+m->f.x;
			m->s2.pos_button_back.y=m->s2.pos_button_back.y+m->f.y;

			m->s.pos_settings.x=m->s.pos_settings.x+m->f.x;
			m->s.pos_settings.y=m->s.pos_settings.y+m->f.y;

			m->pos_credit.x=m->pos_credit.x+m->f.x;
			m->pos_credit.y=m->pos_credit.y+m->f.y;

			m->pos_button_play.x=m->pos_button_play.x+m->f.x;
			m->pos_button_play.y=m->pos_button_play.y+m->f.y;

			m->pos_button_exit.x=m->pos_button_exit.x+m->f.x;
			m->pos_button_exit.y=m->pos_button_exit.y+m->f.y;

			m->pos_button_credit.x=m->pos_button_credit.x+m->f.x;
			m->pos_button_credit.y=m->pos_button_credit.y+m->f.y;

			m->pos_button_settings.x=m->pos_button_settings.x+m->f.x;
			m->pos_button_settings.y=m->pos_button_settings.y+m->f.y;
			
			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;
			m->s2.pos_curseurvol.y=373;


		}
	else
	if((pos_mouse(inp,m->s2.pos_button_fullscreen.x,m->s2.pos_button_fullscreen.x+m->s2.pos_button_fullscreen.w,m->s2.pos_button_fullscreen.y,m->s2.pos_button_fullscreen.y+m->s2.pos_button_fullscreen.h)==1)&&(m->s2.mode==0))//here
		{
			m->s2.mode=1;
			m->affichtest=0;
			screen = SDL_SetVideoMode(1920,1080,32, SDL_FULLSCREEN| SDL_DOUBLEBUF);
			m->f.x=150;
			m->f.y=100;			
			
			m->c.pos_credit1.x=m->c.pos_credit1.x+m->f.x;
			m->c.pos_credit2.x=m->c.pos_credit2.x+m->f.x;
			m->c.pos_credit3.x=m->c.pos_credit3.x+m->f.x;
			m->c.pos_credit4.x=m->c.pos_credit4.x+m->f.x;
			m->c.pos_credit4_5.x=m->c.pos_credit4_5.x+m->f.x;
			m->c.pos_credit5.x=m->c.pos_credit5.x+m->f.x;
			m->c.pos_credit6.x=m->c.pos_credit6.x+m->f.x;
			
			m->c.pos_credit1.y=m->c.pos_credit1.y+m->f.y;
			m->c.pos_credit2.y=m->c.pos_credit2.y+m->f.y;
			m->c.pos_credit3.y=m->c.pos_credit3.y+m->f.y;
			m->c.pos_credit4.y=m->c.pos_credit4.y+m->f.y;
			m->c.pos_credit4_5.y=m->c.pos_credit4_5.y+m->f.y;
			m->c.pos_credit5.y=m->c.pos_credit5.y+m->f.y;
			m->c.pos_credit6.y=m->c.pos_credit6.y+m->f.y;
			
			m->s.pos_soundminus.x=m->s.pos_soundminus.x+m->f.x;
			m->s.pos_soundminus.y=m->s.pos_soundminus.y+m->f.y;

			m->s.pos_soundplus.x=m->s.pos_soundplus.x+m->f.x;
			m->s.pos_soundplus.y=m->s.pos_soundplus.y+m->f.y;

			m->s.pos_soundon.x=m->s.pos_soundon.x+m->f.x;
			m->s.pos_soundon.y=m->s.pos_soundon.y+m->f.y;

			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;//here
			m->s2.pos_curseurvol.y=m->s2.pos_curseurvol.y+m->f.y;
			
			m->s2.pos_button_fullscreen.x=m->s2.pos_button_fullscreen.x+m->f.x;
			m->s2.pos_button_fullscreen.y=m->s2.pos_button_fullscreen.y+m->f.y;

			m->s2.pos_button_windowed.x=m->s2.pos_button_windowed.x+m->f.x;
			m->s2.pos_button_windowed.y=m->s2.pos_button_windowed.y+m->f.y;
		
			m->s2.pos_button_back.x=m->s2.pos_button_back.x+m->f.x;
			m->s2.pos_button_back.y=m->s2.pos_button_back.y+m->f.y;

			m->s.pos_settings.x=m->s.pos_settings.x+m->f.x;
			m->s.pos_settings.y=m->s.pos_settings.y+m->f.y;

			m->pos_credit.x=m->pos_credit.x+m->f.x;
			m->pos_credit.y=m->pos_credit.y+m->f.y;

			m->pos_button_play.x=m->pos_button_play.x+m->f.x;
			m->pos_button_play.y=m->pos_button_play.y+m->f.y;

			m->pos_button_exit.x=m->pos_button_exit.x+m->f.x;
			m->pos_button_exit.y=m->pos_button_exit.y+m->f.y;

			m->pos_button_credit.x=m->pos_button_credit.x+m->f.x;
			m->pos_button_credit.y=m->pos_button_credit.y+m->f.y;

			m->pos_button_settings.x=m->pos_button_settings.x+m->f.x;
			m->pos_button_settings.y=m->pos_button_settings.y+m->f.y;

			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;
			m->s2.pos_curseurvol.x=588;
		}
}


void Mise_a_jour_menu(menu *m,input *inp,int *continuer,SDL_Surface* screen)
{
	if(m->menu==0)
	{
	if(inp->keys.down==1)
		{
			m->soundcontrol=0;
			if(m->arrowpos<4)
				{m->arrowpos++;
				SDL_Delay(200);}
			else
				{m->arrowpos=1;
				SDL_Delay(200);}
		}
	if(inp->keys.up==1)
		{
			m->soundcontrol=0;
			if(m->arrowpos>1)
				{m->arrowpos--;
				SDL_Delay(200);}
			else
				{m->arrowpos=4;
				SDL_Delay(200);}
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_play.x,m->pos_button_play.x+m->pos_button_play.w,m->pos_button_play.y,m->pos_button_play.y+m->pos_button_play.h)==1)
		{
			m->buttonchoix=1;
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_settings.x,m->pos_button_settings.x+m->pos_button_settings.w,m->pos_button_settings.y,m->pos_button_settings.y+m->pos_button_settings.h)==1)
		{
			m->buttonchoix=2;
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_credit.x,m->pos_button_credit.x+m->pos_button_credit.w,m->pos_button_credit.y,m->pos_button_credit.y+m->pos_button_credit.h)==1)
		{
			m->buttonchoix=3;
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_exit.x,m->pos_button_exit.x+m->pos_button_exit.w,m->pos_button_exit.y,m->pos_button_exit.y+m->pos_button_exit.h)==1)
		{
			m->buttonchoix=4;
		}
	if(m->buttonchoix>0)
		{
			m->arrowpos=0;
		}
	if((m->buttonchoix>0)&&(m->affonetime==0))
		{
			m->affonetime=1;
			m->soundcontrol=0;
		}
	else
	if(m->buttonchoix==0)
			m->affonetime=0;

	if((pos_mouse(*inp,m->pos_button_play.x,m->pos_button_play.x+m->pos_button_play.w,m->pos_button_play.y,m->pos_button_play.y+m->pos_button_play.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==1))
		{
			inp->mouse.click=0;
			m->p.affich_Load_multi_onetime=0;
			m->menu=1;
		}
	if((pos_mouse(*inp,m->pos_button_settings.x,m->pos_button_settings.x+m->pos_button_settings.w,m->pos_button_settings.y,m->pos_button_settings.y+m->pos_button_settings.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==2))
		{
			inp->mouse.click=0;
			m->menu=2;
		}
	if((pos_mouse(*inp,m->pos_button_credit.x,m->pos_button_credit.x+m->pos_button_credit.w,m->pos_button_credit.y,m->pos_button_credit.y+m->pos_button_credit.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==3))
		{
			inp->mouse.click=0;
			m->menu=3;
		}
	if((pos_mouse(*inp,m->pos_button_exit.x,m->pos_button_exit.x+m->pos_button_exit.w,m->pos_button_exit.y,m->pos_button_exit.y+m->pos_button_exit.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==4))
		*continuer=0;
	
	}	
	if(m->menu==1)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=0;
				m->affichbackmenuonetime=0;
				SDL_Delay(500);}
			m->buttonchoix=0;
			m->affonetime=1;
			menuLoad(m,inp);//here
				
		}
	if(m->menu==2)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=0;
				m->affichbackmenuonetime=0;}
			m->buttonchoix=0;
			m->affonetime=1;
			m->s.testvol=-1;
			Volume(m,*inp);
			fullscreen_windowed(m,*inp,screen);
		}
	if(m->menu==3)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=0;
				m->affichbackmenuonetime=0;}
			m->buttonchoix=0;
			m->affonetime=1;
		}
	if(m->menu==5)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=1;
				m->p.affich_Load_multi_onetime=0;
				SDL_Delay(500);
				}
			menu_multiplayer(m,inp);//here		
		}
}

//free
void free_Menu(menu *m)
{
	int i;
	SDL_FreeSurface(m->ouverture_texte);
	SDL_FreeSurface(m->ouverture_back);
	for(i=0;i<4;i++)
	{
		SDL_FreeSurface(m->menu_back[i]);
	}

	SDL_FreeSurface(m->button_play_on);
	SDL_FreeSurface(m->button_play_off);
	SDL_FreeSurface(m->button_exit_on);
	SDL_FreeSurface(m->button_exit_off);
	SDL_FreeSurface(m->button_credit_on);
	SDL_FreeSurface(m->button_credit_off);
	SDL_FreeSurface(m->button_settings_on);
	SDL_FreeSurface(m->button_settings_off);
	SDL_FreeSurface(m->s.img_soundminus);
	SDL_FreeSurface(m->s.img_soundplus);
	SDL_FreeSurface(m->s.img_soundon);
	SDL_FreeSurface(m->s.img_soundoff);
	SDL_FreeSurface(m->s2.img_curseurvol);
	SDL_FreeSurface(m->s2.button_fullscreenon);
	SDL_FreeSurface(m->s2.button_windowedon);
	SDL_FreeSurface(m->s2.button_fullscreenoff);
	SDL_FreeSurface(m->s2.button_windowedoff);
	SDL_FreeSurface(m->s2.button_back);
	SDL_FreeSurface(m->c.texte_credit1);
	SDL_FreeSurface(m->c.texte_credit2);
	SDL_FreeSurface(m->c.texte_credit3);
	SDL_FreeSurface(m->c.texte_credit4);
	SDL_FreeSurface(m->c.texte_credit5);
	SDL_FreeSurface(m->c.texte_credit6);
	SDL_FreeSurface(m->f.fullscreen_back);
	SDL_FreeSurface(m->p.multi_back);
	SDL_FreeSurface(m->p.Load_back);//here
	Mix_FreeChunk(m->sound);
}



// entite
//1
void initialiserbackg(back *A)
{

    A->img =SDL_LoadBMP("ennemi.bmp");
		if (A->img== NULL) {
			return ;
		}
	A->pos1.x=0;
	A->pos1.y=0;
	A->pos1.w=0;
	A->pos1.h=0;


}


void initEnnemi(Ennemi *e)
{
e->enem[0] = IMG_Load("8.png");
e->enem[1] = IMG_Load("9.png");
e->enem[2] = IMG_Load("10.png");
e->enem[3] = IMG_Load("11.png");
e->enem[4] = IMG_Load("12.png");
e->enem[5] = IMG_Load("13.png");
e->enem[6] = IMG_Load("14.png");
e->enem[7] = IMG_Load("15.png");
e->enem[8] = IMG_Load("1.png");
e->enem[9] = IMG_Load("2.png");
e->enem[10] = IMG_Load("3.png");
e->enem[11] = IMG_Load("4.png");
e->enem[12] = IMG_Load("5.png");
e->enem[13] = IMG_Load("6.png");
e->enem[14] = IMG_Load("7.png");
e->enem[15] = IMG_Load("16.png");
e->enem[16] = IMG_Load("17.png");
e->pos.x=300;
e->pos.y=400;
e->pos.h=0;
e->pos.w=0;




e->d=0;
e->num=0;

}

void afficherEnnemi(Ennemi e, SDL_Surface *screen)
{
if (e.pos.x>=0)
{
SDL_BlitSurface(e.enem[e.num],NULL,screen,&e.pos);
SDL_Flip(screen);}
}




void animerEnnemi( Ennemi * e,SDL_Surface *screen)
{
SDL_Delay(200);

SDL_Flip(screen);
e->num ++;
 if (e->num==16)
{ e->num=0;}
     //else e->num ++;

  }
/*
void deplacer( Ennemi * e)
{
int posmax=700;
int posmin=150;
     if (e->pos.x <= posmin)
          e->d=1;

     if (e->pos.x >= posmax)
          e->d=0;


     if (e->d== 1)
       e->pos.x=e->pos.x+50;
     else 
       e->pos.x=e->pos.x-50;



}
*/
void deplacer( Ennemi * e)
{
int posmax=650;
int posmin=300;
 if (e->pos.x > posmax)
    {
        e->d=1;
    }
    if (e->pos.x < posmin)
    {
        e->d=0;
    }
if (e->d==0)
    {
        e->pos.x += 50;
    }else if (e->d==1)
    {
        e->pos.x -= 50;
    }

     } 

int collisionBB( Personne p, Ennemi e)
{
int Collision;
if( (p.pos.x + p.pos.w < e.pos.x ) 
   ||(p.pos.x>  e.pos.x + e.pos.w) 
    ||(p.pos.y + p.pos.h< e.pos.y) ||
       (p.pos.y>  e.pos.y + e.pos.h ) )
            Collision = 0 ;       // pas de collision
else
            Collision = 1;
return Collision;
}

/*
int collisionBB( SDL_Rect positionpersonage, Ennemi e)
{
int Collision;
if( (positionpersonage.x + positionpersonage.w < e.pos. x) 
   ||(positionpersonage.x>  e.pos. x + e.pos. w) 
    ||(positionpersonage.y + positionpersonage.h< e.pos. y) ||
       (positionpersonage.y>  e.pos. y + e.pos. h ) )
            Collision = 0 ;       // pas de collision
else
            Collision = 1;
return Collision;
}*/
//////////////////////////////////////

//////////////////////////////////////
void affiche_back(back p, SDL_Surface* screen)
{
SDL_BlitSurface(p.img,NULL,screen,&p.pos1);

}









void initialiser_score(vie *v){
    v->vie[0]=IMG_Load("health1.png");
    v->vie[1]=IMG_Load("health1.png");
    v->vie[2]=IMG_Load("health1.png");
    v->vie[3]=IMG_Load("health2.png");
    v->vie[4]=IMG_Load("health2.png");
     v->vie[5]=IMG_Load("health2.png");
    v->vie[6]=IMG_Load("health4.png");
   v->vie[7]=IMG_Load("health4.png");
    v->vie[8]=IMG_Load("health4.png");
v->vie[9]=IMG_Load("health4.png");


    v->pos.x=50;
    v->pos.y=100;
    v->pos_spr.x=0;
    v->pos_spr.y=0;
    v->pos_spr.h=50;
    v->pos_spr.w=200;

v->valeur_vie=0;
}void initialiser_score2(vie *v){
    v->vie[0]=IMG_Load("h1.png");
    v->vie[1]=IMG_Load("h1.png");
    v->vie[2]=IMG_Load("h1.png");
    v->vie[3]=IMG_Load("h2.png");
    v->vie[4]=IMG_Load("h2.png");
     v->vie[5]=IMG_Load("h2.png");
    v->vie[6]=IMG_Load("h4.png");
   v->vie[7]=IMG_Load("h4.png");
    v->vie[8]=IMG_Load("h4.png");
v->vie[9]=IMG_Load("h4.png");


    v->pos.x=400;
    v->pos.y=100;
    v->pos_spr.x=0;
    v->pos_spr.y=0;
    v->pos_spr.h=50;
    v->pos_spr.w=200;

v->valeur_vie=0;
}
void afficher_vie(vie v,SDL_Surface* screen){
    SDL_BlitSurface(v.vie[v.valeur_vie],NULL,screen,&v.pos);
SDL_Flip(screen);
}






void deplacerIA(Ennemi *E,Personne p ) {
  if (((E->pos.x - p.pos.x) < 200) && ((E -> pos.x - p.pos.x) > 80))  
   {
    E -> d = 1; 
    E -> pos.x -= 10;
  } 
  else if (((E -> pos.x - p.pos.x) < -80) && ((E -> pos.x - p.pos.x) > -400))
   {
    E -> d = 0; 
    E -> pos.x += 10;
  } 
  else if (((E -> pos.x - p.pos.x) <= 80) && ((E -> pos.x - p.pos.x) >= 0)) 
  {
    E -> d =1;
  } 
  else if (((E -> pos.x - p.pos.x) <= 0) && ((E -> pos.x - p.pos.x) >= -80)) 
  {
    E -> d = 0;

  }
  else 
deplacer(E);

}


void initPerso(Personne *p)
{


p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;
p->time=0;
p->score=0;
p->dt=0;
p->num1=0;

p->num2=0;

p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("lf2.png");
p->image[0][1]=IMG_Load("rf1.png");
p->image[1][0]=IMG_Load("lf2_inverse.png");
p->image[1][1]=IMG_Load("rf_inverse.png");
p->image[2][0]=IMG_Load("attack_lf.png");
p->image[2][1]=IMG_Load("attac_rf.png");
p->image[3][0]=IMG_Load("attack_lf_inverse.png");
p->image[3][1]=IMG_Load("attac_lf_inv.png");
p->image[4][0]=IMG_Load("lf2.png");
p->image[4][1]=IMG_Load("lf2.png");
p->image[5][0]=IMG_Load("rf_inverse.png");
p->image[5][1]=IMG_Load("rf_inverse.png");
p->up=0;
p->nump=0;
initialiser_score(&(p->v));

}
void initPerso2(Personne *p)
{

p->posvie.x=900;
p->posvie.y=20;
p->pos.x=30;
p->pos.y=275;

p->dt=0;
p->num1=0;

p->num2=0;

p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("lf21.png");
p->image[0][1]=IMG_Load("rf11.png");
p->image[1][0]=IMG_Load("lf2_inverse1.png");
p->image[1][1]=IMG_Load("rf_inverse1.png");
p->image[2][0]=IMG_Load("attack_lf1.png");
p->image[2][1]=IMG_Load("attac_rf1.png");
p->image[3][0]=IMG_Load("attack_lf_inverse1.png");
p->image[3][1]=IMG_Load("attac_lf_inv1.png");
p->image[4][0]=IMG_Load("lf21.png");
p->image[4][1]=IMG_Load("lf21.png");
p->image[5][0]=IMG_Load("rf_inverse1.png");
p->image[5][1]=IMG_Load("rf_inverse1.png");
p->up=0;
p->nump=0;
initialiser_score2(&(p->v));

}
//perso3
void initPerso3(Personne *p)
{


p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;
p->time=0;
p->score=0;
p->dt=0;
p->num1=0;

p->num2=0;

p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("starp_lf.png");
p->image[0][1]=IMG_Load("starp_rf.png");
p->image[1][0]=IMG_Load("starp_lf_inv.png");
p->image[1][1]=IMG_Load("starp_rf_inv.png");
p->image[2][0]=IMG_Load("attackstr_lf.png");
p->image[2][1]=IMG_Load("attackstr_rf.png");
p->image[3][0]=IMG_Load("attackstr_lf_inv.png");
p->image[3][1]=IMG_Load("attackstr_rf_inv.png");
p->image[4][0]=IMG_Load("starp_lf.png");
p->image[4][1]=IMG_Load("starp_lf.png");
p->image[5][0]=IMG_Load("attackstr_rf_inv.png");
p->image[5][1]=IMG_Load("attackstr_rf_inv.png");
p->up=0;
p->nump=0;
initialiser_score(&(p->v));

}

//perso4

void initPerso4(Personne *p)
{


p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;
p->time=0;
p->score=0;
p->dt=0;
p->num1=0;

p->num2=0;

p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("str2_lf.png");
p->image[0][1]=IMG_Load("str2_rf.png");
p->image[1][0]=IMG_Load("str2_lf_inv.png");
p->image[1][1]=IMG_Load("str2_rf_inv.png");
p->image[2][0]=IMG_Load("attack_str2_lf.png");
p->image[2][1]=IMG_Load("attack_str2_rf.png");
p->image[3][0]=IMG_Load("attack_str2_lf_inv.png");
p->image[3][1]=IMG_Load("attack_str2_rf_inv.png");
p->image[4][0]=IMG_Load("str2_lf.png");
p->image[4][1]=IMG_Load("str2_lf.png");
p->image[5][0]=IMG_Load("st2_rf_inv.png");
p->image[5][1]=IMG_Load("st2_rf_inv.png");
p->up=0;
p->nump=0;
initialiser_score(&(p->v));

}







void afficherPerso(Personne *p, SDL_Surface *screen)
{
SDL_Rect b;

b.x=0;
b.y=0;

//SDL_BlitSurface(p->vimg[p->vie],NULL,screen,&p->posvie);
        SDL_BlitSurface(p->image[p->dt][p->nump],NULL,screen,&p->pos);

afficher_vie( p->v,screen);

        
SDL_Flip(screen);
}

void deplacerPerso(Personne*p,int dt)
{
switch (dt)
{
case 0: 
p->pos.x+=50;


break;
case 1:
p->pos.x-=50;
break;


}//fin switch
}//fin fonction
  



void animerPerso(Personne *p, SDL_Surface *screen)
{

SDL_Rect b;
b.x=0;
b.y=0;

p->nump++;
 
if(p->nump>1)
p->nump=0;  

SDL_Flip(screen);
}

void saut (Personne* p) {
    if (p->pos.y == p->ground)
    {
       p->vs=-50;
       p->up=1;
    }
    
}


////------------------
choix_menu choix(SDL_Surface *screen)
{
SDL_Surface* bg1=IMG_Load("choix_perso.png");
SDL_Surface* bg2=IMG_Load("choix_input.png");
SDL_Surface* c1=IMG_Load("azrek.png");
SDL_Surface* c2=IMG_Load("akhel.png");
SDL_Surface* c3=IMG_Load("ahmer.png");
choix_menu monchoix; 
int loop=0,ch=-1;
SDL_Event event;
SDL_BlitSurface(bg1,NULL,screen,NULL);SDL_Flip(screen);
while(ch==-1)
{	SDL_PollEvent(&event);
        if(event.type==SDL_KEYDOWN)
{switch(event.key.keysym.sym)
       {
            case SDLK_v:
              ch=1;
            break;
            case SDLK_b :
              ch=2;
            break;
            case SDLK_n:
              ch=3;
            break;


}}
}
monchoix.joueur=ch;
if(ch==1)
SDL_BlitSurface(c1,NULL,screen,NULL);
if(ch==2)
SDL_BlitSurface(c2,NULL,screen,NULL);
if(ch==3)
SDL_BlitSurface(c3,NULL,screen,NULL);
if(ch==4)
SDL_BlitSurface(c3,NULL,screen,NULL);

SDL_Flip(screen);
SDL_Delay(2000);
ch=-1;
SDL_BlitSurface(bg2,NULL,screen,NULL);SDL_Flip(screen);
monchoix.input=ch;
SDL_Flip(screen);
SDL_Delay(2000);
printf("choix1:%d\nchoix2:%d\n",monchoix.joueur,monchoix.input);
return monchoix;
}







//------------------
void freePerso(Personne *p)
{
SDL_FreeSurface(p->background);

SDL_FreeSurface(p->right[0]);
SDL_FreeSurface(p->right[1]);
SDL_FreeSurface(p->left[0]);
SDL_FreeSurface(p->left[1]);
SDL_FreeSurface(p->right[0]);

SDL_FreeSurface(p->attack[0]);
SDL_FreeSurface(p->attack[1]);

}


//------------------------------------------------------------
int arduinoWriteData(int x)
{
    char chemin[]="/dev/ttyUSB0";
    FILE*f=NULL;

    f=fopen(chemin,"w");
    if(f == NULL)
        return(-1);

    fprintf(f,"%d",x);
    fclose(f);

    return(0);
}

int arduinoReadData(int *x)
{
    char chemin[]="/dev/ttyUSB0";
    FILE*f=NULL;
    char c;
    f=fopen(chemin,"r");

    if(f == NULL)
        return(-1);

    fscanf(f,"%d",x);

    fclose(f);

    return(0);
}
//---------------------------------------------------------------

//-------------------enigme image--------------------------------

void init_enigme_im(enigmeim * e)
{
	e->p.x=0;
	e->p.y=0;	
	e->img=NULL;


}

 void generate_afficher (SDL_Surface * screen  , char image [],enigmeim *e,int *alea)
{ 
	int test=*alea ;
do{
 *alea = 1+ rand()%3;
}while(*alea==test) ;
 sprintf(image ,"%d.jpg",*alea);
e->img = IMG_Load(image);
 SDL_BlitSurface(e->img,NULL,screen,&(e->p)) ;
  SDL_Flip(screen) ;
}
 
 int solution_e (char image [])
 {
 	int solution =0 ;
 	
 	if(strcmp(image,"1.jpg")==0)
 	{
     solution =3 ;
 	}
 	else  	if(strcmp(image,"2.jpg")==0)
 	{
 		solution =2;

 	}
 	else 	if(strcmp(image,"3.jpg")==0)
 	{
 		solution =4;	
 	}
 	return solution;
 }

int resolution_im (int * running,int *run )
{
	SDL_Event event ;
  int r=0 ;
	SDL_PollEvent(&event);
	switch(event.type)
	{
		  case SDL_QUIT:
			        *running= 0 ;
                *run = 0;
				break ;

       case SDL_KEYDOWN : 
            switch( event.key.keysym.sym )
                {
			  case  SDLK_a: 
			  r= 1;
			   break ;
			   case  SDLK_z :
			   r= 2;
			   break;
			   case SDLK_e: 
			   r=3 ;
			   break;
			    case  SDLK_r: 
			   r= 4;
			   break ;
			    }
       break ;

                 
	}
  return r ;
}
 
 void afficher_resultat (SDL_Surface * screen,int s,int r,enigmeim *en)
 {
 
 
 
 	if (r==s)
 	{
 		en->img=IMG_Load("00.png");
 		SDL_BlitSurface(en->img, NULL, screen, &(en->p)) ;
        SDL_Flip(screen);
 	}
 	else
 	{
 		en->img=IMG_Load("44.png");
 		SDL_BlitSurface(en->img, NULL, screen, &(en->p)) ;
        SDL_Flip(screen);
 	}
 }
 

//----------------------------------------------------------------

//---------------enigme texte--------------------------------------

//-----------------------------------------INIT------------------------------------
//INIT Background
/**
* @brief To initialize the background .
* @param B the background
* @return Nothing
*/
void initialiser_back_enigme_fichier(enigme *B)
{

(*B).img_back=IMG_Load("RES/back enigme ficher.jpg");
  if((*B).img_back==NULL)
{printf("loading error ! %s\n", SDL_GetError());
 return;}

(*B).pos_back.x=0;
(*B).pos_back.y=0;
(*B).pos_back.w=0;
(*B).pos_back.h=0;
}
//------------------------TEXT------------------------------
/**
* @brief To initialize the text .
* @param t the text
* @return Nothing
*/
void initText_im(enigme *t)
{
t->textColor.r=255;
t->textColor.g=255;
t->textColor.b=255;
t->font=TTF_OpenFont("RES/Basketball.otf",40);
}
//--------------------------TEMPS----------------------------------
/**
* @brief To initialize the time .
* @param t the time
* @return Nothing
*/
void initialiser_temps_enigme(temps *t)
{
 //t->texte = NULL;
 t->position.x=50;
 t->position.y=10;
 t->police = TTF_OpenFont("RES/Basketball.otf",75);
 strcpy( t->entree,"");
(t->secondesEcoulees)=0;
time(&(t->t1));	 //temps du debut
}
//------------------------MUSIC------------------------------
/**
* @brief To initialize the music .
* @return Nothing
*/
void initmusic_im()
{
	Mix_Music *music;
if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)

	{printf("NO AUDIO %s\n",Mix_GetError());}

 

music = Mix_LoadMUS("RES/enigme son.mp3"); //load the music 

Mix_PlayMusic(music,-1); //play music 
}
//-----------------------VOLUME-----------------------------
/**
* @brief To initialize the volume .
* @param O the volume
* @return Nothing
*/
 void initialiser_volume_im(volume *O)  		
{
(*O).img_soundminus= IMG_Load("RES/soundminus.png");
(*O).img_soundplus= IMG_Load("RES/soundplus.png");


(*O).pos_soundminus.x=1100;
(*O).pos_soundminus.y=150;
(*O).pos_soundminus.w=60;
(*O).pos_soundminus.h=60;

(*O).pos_soundplus.x=1100;
(*O).pos_soundplus.y=50;
(*O).pos_soundplus.w=60;
(*O).pos_soundplus.h=60;
}
//----------------------MUTE-----------------------------
/**
* @brief To initialize the mute .
* @param O the mute
* @return Nothing
*/

void initialiser_mute(mute *O)  		
{
(*O).img_soundon= IMG_Load("RES/soundon.png");
(*O).img_soundoff= IMG_Load("RES/soundoff.png");
(*O).img_soundsupp= IMG_Load("RES/soundsupp.png");

(*O).pos_soundon.x=1000;
(*O).pos_soundon.y=100;
(*O).pos_soundon.w=60;
(*O).pos_soundon.h=60;
}
//----------------------INIT----------------------------
/**
* @brief To initialize everything.
* @param e for enigme
* @param O for volume
* @param m for mute
* @param anim for animation
* @return Nothing
*/
void initialisation(enigme *e,volume *O,mute *m,temps *t,SDL_Surface *anim[])
{
initialiser_back_enigme_fichier(e);
initText_im(e);
init_enig_fichier(e);	
initmusic_im();
initialiser_volume_im(O);
initialiser_mute(m);
initialiser_temps_enigme(t);
initanimation(anim);
e->resolu=0;
system("stty -F /dev/ttyUSB0 9600 -parenb cs8 -cstopb");
}
//----------------------ENIGME----------------------------
/**
* @brief To initialize enigme.
* @param en the enigme
* @return Nothing
*/
void init_enig_fichier( enigme * en )
{

    en->solution = 0;
    en->correct =IMG_Load("RES/pass.png");
    en->wrong =IMG_Load("RES/fail.png");
    en->position_correct.x = 450;
    en->position_correct.y = 300;
    en->position_wrong.x = 450;
    en->position_wrong.y = 300;


    en->Rep1 = NULL;
    en->rep1_Pos.x=230;
    en->rep1_Pos.y=310;
    en->rep1_Pos.w=440;
    en->rep1_Pos.h=100;

    en->Rep2 = NULL;
    en->rep2_Pos.x=720;
    en->rep2_Pos.y=310;
    en->rep2_Pos.w=440;
    en->rep2_Pos.h=100;

    en->Rep3 =NULL;
    en->rep3_Pos.x=230;
    en->rep3_Pos.y=580;
    en->rep3_Pos.w=440;
    en->rep3_Pos.h=100;

    en->Rep4 =NULL;
    en->rep4_Pos.x=720;
    en->rep4_Pos.y=580;
    en->rep4_Pos.w=440;
    en->rep4_Pos.h=100;


    en->Question = NULL;
    en->question_Pos.x=200;
    en->question_Pos.y=100;

    en->alea = 0;
}
//---------------------------ANIMATION---------------------TIME OUT-------
/**
* @brief To initialize the animation .
* @param anim the animation
* @return Nothing
*/
void initanimation(SDL_Surface *anim[])
{ int i;
  char filename[43];
for(i=0;i<4;i++)
{
sprintf(filename,"RES/animation/%d.png",i); 
anim[i] = IMG_Load(filename);
}
}
//---------------------------AFFICHER ANIM-----------------------
/**
* @brief To show the animation anim .
* @param screen the screen
* @param B the enigme
* @param anim the animation
* @return Nothing
*/
void afficheanimation(SDL_Surface* screen,enigme *B,SDL_Surface *anim[4])
{	      
	int ianimation=0;
	for (ianimation=0;ianimation<4;ianimation++)
	{
	SDL_BlitSurface(anim[ianimation],NULL,screen,&B->pos_back);
	SDL_Flip(screen);
	SDL_Delay(600);
	}

}
//-----------------------------AFFICHER TEMPS----------------------
/**
* @brief To show the time .
* @param screen the screen
* @param en the enigme
* @param t the time
* @return Nothing
*/
void afficher_temps_enigme(temps *t,SDL_Surface *screen,enigme *en)
{	
    	time(&(t->t2));// temps actuel
	t->secondesEcoulees = t->t2 - t->t1;
        t->min=0-((t->secondesEcoulees/60)%60);
	t->sec= 20-((t->secondesEcoulees)%60);
	sprintf(t->entree,"%02d:%02d",t->min,t->sec);
        t->texte = TTF_RenderText_Blended(en->font,t->entree, en->textColor);
	SDL_BlitSurface(t->texte, NULL, screen, &(t->position)); /* Blit du texte */	
}
//-----------------------------AFFICHER ENIGME----------------------
/**
* @brief To show the enigme .
* @param screen the screen
* @param en the enigme
* @param m the mute
* @param o the volume
* @return Nothing
*/
void blit_enig_fichier ( enigme *en, SDL_Surface* screen,mute m,volume O)
{	      
	SDL_BlitSurface(en->img_back,NULL,screen,&en->pos_back);
	SDL_BlitSurface(en->Question,NULL,screen,&en->question_Pos);
	SDL_BlitSurface(en->Rep1,NULL,screen,&en->rep1_Pos);
        SDL_BlitSurface(en->Rep2,NULL,screen,&en->rep2_Pos);
        SDL_BlitSurface(en->Rep3,NULL,screen,&en->rep3_Pos);
	SDL_BlitSurface(en->Rep4,NULL,screen,&en->rep4_Pos);
	SDL_BlitSurface(O.img_soundminus,NULL,screen,&O.pos_soundminus);
	SDL_BlitSurface(O.img_soundplus,NULL,screen,&O.pos_soundplus);
	SDL_BlitSurface(m.img_soundon,NULL,screen,&m.pos_soundon);
}
//------------------------------ALEA ENIGME------------------------
/**
* @brief To make the alea .
* @param en the enigme
* @return Nothing
*/
void alea_enig_fichier(enigme *en)
{
	FILE* fichier = NULL;
	FILE* fichier_reponse = NULL;
	char ques[60] ;
	char rep1[20] ;
	char rep2[20] ;
	char rep3[20] ;
	char rep4[20] ;
	int caracterelu_question,caracterelu_reponses,ligne =1,ligne_reponse=1;
	srand(time(0));

		en->alea = rand()%6 +1;
	

	fichier_reponse = fopen("RES/reponse.txt","r"); 
	fichier = fopen("RES/question.txt","r"); 
	if ( fichier != NULL && fichier_reponse != NULL )
	{
		while ( caracterelu_question!=EOF && ligne < en->alea )
		{
			caracterelu_question = fgetc(fichier);
			if ( caracterelu_question == '\n')
				ligne++;
		}
		fgets(ques,100,fichier);
		fclose(fichier);
		while ( caracterelu_reponses!=EOF && ligne_reponse < en->alea )
		{
			caracterelu_reponses = fgetc(fichier_reponse);
			if ( caracterelu_reponses == '\n')
				ligne_reponse++;
		}
		fscanf(fichier_reponse,"%s %s %s %s %d",rep1,rep2,rep3,rep4,&en->solution);
		fclose(fichier_reponse);
	}
	en->Question = TTF_RenderText_Blended(en->font,ques,en->textColor);
	en->Rep1 = TTF_RenderText_Blended(en->font,rep1,en->textColor);
	en->Rep2 = TTF_RenderText_Blended(en->font,rep2,en->textColor);
	en->Rep3 = TTF_RenderText_Blended(en->font,rep3,en->textColor);
	en->Rep4 = TTF_RenderText_Blended(en->font,rep4,en->textColor);
}
//-------------------------------RESOLUTION---------------------------
/**
* @brief To do the resolution.
* @param en for enigme
* @param O for volume
* @param m for mute
* @param screen the screen
* @param t the time
* @param anim for animation
* @return Nothing
*/
void resolution(enigme *en, SDL_Surface* screen,volume O,mute m,temps t,SDL_Surface *anim[])
{
SDL_Event event;
int continuer=1;
alea_enig_fichier(en);
int x,y,choix=0;
int volume=20,Vol,ard=0;
		while(continuer == 1)	
			{
			
			blit_enig_fichier (en,screen,m,O);
			afficher_temps_enigme(&t,screen,en);
if ((t.min==0)&&(t.sec==0))
{	    afficheanimation(screen,en,anim);
		continuer=0;
}
			arduinoReadData(&ard);
		    	SDL_PollEvent(&event);
	switch(event.type)
		{
			case SDL_QUIT:
            			continuer=0;
           		 break;	

			case  SDL_MOUSEMOTION: 
        			 x=event.motion.x;
        			 y=event.motion.y;
			case SDL_MOUSEBUTTONDOWN:
//---------------------------VOLUME SOURIS-------------------------
			if  ( ( x > O.pos_soundminus.x ) && ( x < O.pos_soundminus.x + O.pos_soundminus.w ) && ( y > O.pos_soundminus.y ) && ( y < O.pos_soundminus.y + O.pos_soundminus.h )&&(event.button.button==SDL_BUTTON_LEFT) )
		{if(volume>0)
     		     {volume-=20;
       		    Mix_VolumeMusic(volume);}
			SDL_Delay(200) ;
}
  		   if ( ( x > O.pos_soundplus.x ) && ( x < O.pos_soundplus.x + O.pos_soundplus.w ) && ( y > O.pos_soundplus.y ) && ( y < O.pos_soundplus.y + O.pos_soundplus.h )&&(event.button.button==SDL_BUTTON_LEFT) )
   		 { if(volume<100)
     		     {volume+=20;
       		    Mix_VolumeMusic(volume);}
			SDL_Delay(200) ;}
		   if ( ( x > m.pos_soundon.x ) && ( x < m.pos_soundon.x + m.pos_soundon.w ) && ( y > m.pos_soundon.y ) && ( y < m.pos_soundon.y + m.pos_soundon.h )&&(event.button.button==SDL_BUTTON_LEFT) )
   		 {
		   if(volume>0)
     		     {Mix_VolumeMusic(0);
		      Vol=volume;
		      volume=0;}
		   else 
     		     {volume=Vol;
       		    Mix_VolumeMusic(volume);}
			SDL_Delay(200) ;}
//-----------------------------REPONSE SOURIS---------------------------
/*rep1*/		if (( x > en->rep1_Pos.x ) && ( x < en->rep1_Pos.x + en->rep1_Pos.w ) && ( y > en->rep1_Pos.y ) && ( y < en->rep1_Pos.y + en->rep1_Pos.h )&&(event.button.button==SDL_BUTTON_LEFT))
		{choix=1;}

/*rep2*/		if (( x > en->rep2_Pos.x ) && ( x < en->rep2_Pos.x + en->rep2_Pos.w ) && ( y > en->rep2_Pos.y ) && ( y < en->rep2_Pos.y + en->rep2_Pos.h )&&(event.button.button==SDL_BUTTON_LEFT)) 
                {choix=2;}
/*rep3*/		if (( x > en->rep3_Pos.x ) && ( x < en->rep3_Pos.x + en->rep3_Pos.w ) && ( y > en->rep3_Pos.y ) && ( y < en->rep3_Pos.y + en->rep3_Pos.h )&&(event.button.button==SDL_BUTTON_LEFT)) 
                {choix=3;}
/*rep4*/		if (( x > en->rep4_Pos.x ) && ( x < en->rep4_Pos.x + en->rep4_Pos.w ) && ( y > en->rep4_Pos.y ) && ( y < en->rep4_Pos.y + en->rep4_Pos.h )&&(event.button.button==SDL_BUTTON_LEFT))
                {choix=4;}
			break;	
//-----------------------------VOLUME CLAVIER---------------------------
		case SDL_KEYDOWN:
		switch (event.key.keysym.sym)
              {
		case SDLK_DOWN: 
          	{if(volume>0)
     		     {volume-=20;
       		    Mix_VolumeMusic(volume);}
			SDL_Delay(200) ;}
           	break;
          	 case SDLK_UP: 
          	{ if(volume<100)
     		     {volume+=20;
       		    Mix_VolumeMusic(volume);}
			SDL_Delay(200) ;}
          	break;
	  	 case SDLK_m: 
          	{
		   if(volume>0)
     		     {Mix_VolumeMusic(0);
		      Vol=volume;
		      volume=0;}
		   else 
     		     {volume=Vol;
       		    Mix_VolumeMusic(volume);}
			SDL_Delay(200) ;}
        	  break;
//-----------------------------REPONSE CLAVIER---------------------------
		case SDLK_u: 
		{choix=1;}
           	break;
		case SDLK_i: 
          	{choix=2;}
           	break;
		case SDLK_k: 
          	{choix=3;}
           	break;
		case SDLK_l: 
          	{choix=4;}
           	break;
}}	
if (volume>0)
		{SDL_BlitSurface(m.img_soundsupp,NULL,screen,&m.pos_soundon);
		SDL_BlitSurface(m.img_soundon,NULL,screen,&m.pos_soundon);
		}
	else
		{SDL_BlitSurface(m.img_soundsupp,NULL,screen,&m.pos_soundon);
		SDL_BlitSurface(m.img_soundoff,NULL,screen,&m.pos_soundon);
		}
		

/*rep2*/	if (ard==4)
		{choix=1;}

/*rep2*/	if (ard==5) 
                {choix=2;}

		
	SDL_Flip(screen);
if (choix!=0) 
{
if ( en->solution == choix )
        {
            SDL_BlitSurface(en->correct,NULL, screen, &en->position_correct );
            SDL_Flip(screen);
		en->resolu=1;
		ard=4;
		arduinoWriteData(ard);
            SDL_Delay(3000);
		continuer=0;

        }
        else 
        {
            SDL_BlitSurface(en->wrong,NULL, screen, &en->position_wrong );

            SDL_Flip(screen);
		en->resolu=2;
		ard=5;
		arduinoWriteData(ard);
            SDL_Delay(3000);
		continuer=0;

        }
}
}}

/**
* @brief To free the enigme.
* @param en the enigme
* @return Nothing
*/
void freee( enigme *en)
{
    SDL_FreeSurface(en->img_back);
    SDL_FreeSurface(en->correct);
    SDL_FreeSurface(en->wrong);
    SDL_FreeSurface(en->Rep1);
    SDL_FreeSurface(en->Rep2);
    SDL_FreeSurface(en->Rep3);
    SDL_FreeSurface(en->Rep4);
    SDL_FreeSurface(en->Question);
    TTF_CloseFont(en->font);
}
//-----------------------------------------------------
/**
* @brief To free the animation.
* @param anim the animation
* @return Nothing
*/
void libereranimation(SDL_Surface *anim[])
{ int i;
  char filename[43];
	for(i=0;i<4;i++)
	{
		SDL_FreeSurface(anim[i]);
	}
}


//-----------------------------BACKGROUND-------------------------------------
/*
void initBack (background *b)
{
//background load et position
    b->imgback=IMG_Load("mask.png");
    b->posback.x=0;
    b->posback.y=0;
//background masque load et position
    b->imgbackm=IMG_Load("mask.png");
    b->posbackm.x=0;
    b->posbackm.y=0;
//camera position et taille
    b->camera.x=0;
    b->camera.y=0;
    b->camera.w=1366;
    b->camera.h=678;
//musique
    b->son=Mix_LoadMUS("music.mp3"); //Chargement de la musique
    Mix_PlayMusic(b->son, -1); //Jouer infiniment la musique
}

void initBack1 (background *b)
{
//background load et position
    b->imgback=IMG_Load("mask.png");
    b->posback1.x=683;
    b->posback1.y=0;
//background masque load et position
    b->imgbackm=IMG_Load("mask.png");
    b->posbackm1.x=683;
    b->posbackm1.y=0;
//camera position et taille
    b->camera1.x=0;
    b->camera1.y=0;
    b->camera1.w=683;
    b->camera1.h=678;
    b->posanim.x=0;
//pos animation
   /* b->posanim.y=0;
    b->frame=0;
    b->anim[0]=IMG_Load("1.png");
    b->anim[1]=IMG_Load("1.png");
    b->anim[2]=IMG_Load("2.png");
    b->anim[3]=IMG_Load("3.png");
}

void afficheBack (background b, SDL_Surface *ecran)
{
    SDL_BlitSurface(b.imgbackm,&b.camera,ecran,&b.posbackm);
    SDL_BlitSurface(b.imgback,&b.camera,ecran,&b.posback);
}

void afficheBack1 (background b, SDL_Surface *ecran)
{
    SDL_BlitSurface(b.imgbackm,&b.camera1,ecran,&b.posbackm1);
    SDL_BlitSurface(b.imgback,&b.camera1,ecran,&b.posback1);
}


SDL_Color GetPixel(SDL_Surface *pSurface, int x, int y)
{
  SDL_Color color;
  Uint32 col = 0;

  // determine position
  char *pPosition = (char *)pSurface->pixels;

  // offset by y
  pPosition += (pSurface->pitch * y);

  // offset by x
  pPosition += (pSurface->format->BytesPerPixel * x);

  // copy pixel data
  memcpy(&col, pPosition, pSurface->format->BytesPerPixel);

  // convert color
  SDL_GetRGB(col, pSurface->format, &color.r, &color.g, &color.b);
  return (color);
}







int collision_Parfaite(SDL_Surface *calque, SDL_Surface *perso, SDL_Rect posperso, int decalage, int d)
{
  SDL_Color col;

  if (d == 1)
  {
    col = GetPixel(calque, posperso.x + perso->w + decalage, posperso.y + (perso->h / 2));
  }
  else if (d == 2)
  {
    col = GetPixel(calque, posperso.x + decalage, posperso.y + (perso->h / 2));
  }
  else if (d == 3)
  {
    col = GetPixel(calque, posperso.x + (perso->w / 2) + decalage, posperso.y);
  }
  else if (d == 4)
  {
    col = GetPixel(calque, posperso.x + (perso->w / 2) + decalage, posperso.y + perso->h);
  }

  printf("%d    %d   %d\n",col.r,col.b,col.g );

  if ((col.r == 0) && (col.b == 0) && (col.g == 0))
  {
    return 1;
  }
  else
  {
    return 0;
  }
}





void animeBackground(background *b)
{   
    if(b->frame==3)
        b->frame=0;
    else b->frame++;
}
*/

























