#include "menu.h"
#include "input.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

#define SCREEN_W 1280
#define SCREEN_H 720

int main()
{ 	int vrai=0;
	int continuer=1;
	menu gamemenu;
	input input_rep;
	SDL_Surface *screen1;
choix_menu choixp;
	int x=0;
	int ard=0;

//Creation de la fenetre
	SDL_Init(SDL_INIT_VIDEO);
	SDL_WM_SetIcon(IMG_Load("RES/Logo/logo.bmp"),NULL);
	screen1=SDL_SetVideoMode(SCREEN_W,SCREEN_H,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	SDL_WM_SetCaption("Assembly Of Eras", NULL);
	
//INIT
TTF_Init();
init_all_menu(&gamemenu,&input_rep);
system("stty -F /dev/ttyUSB0 9600 -parenb cs8 -cstopb");
//GAME LOOP
//init perso enemi
 Ennemi e;
 int c;
	SDL_Surface *screen;
	int quitter = 0,q=0;
           vie v;
           int up=0,up2=0;
	back b;
//--------------------enigme image------
	enigmeim  eimg;
	
	int s,r,run =1,running=1,alea;
	char image[30]="";

	SDL_Event event;
	    srand(time(NULL));
SDL_Event event_img;
//---------------------------------------

//---------enigme texte-----------------------------------------------------------

	enigme en;
	volume O;
	mute m;
	Mix_Music* music;
	temps t;
	SDL_Surface* anim[4];
	int *ianimation=0;
//init
	initialisation(&en,&O,&m,&t,anim);

//------------------------------------------------------------------------

        int play=0; // variable indiquant si le son bref doit etre joué ou non
	//atexit(SDL_Quit);
	// creation d'une fenetre
	screen= SDL_SetVideoMode(1280, 720, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
	
	
//Initialisation des variables
         
initialiserbackg( &b);
Personne p,p2,p3,p4;
     initEnnemi(&e);
initPerso(&p);
initPerso2(&p2);
 initPerso3(&p3); 
initPerso4(&p4);    
init_enigme_im(&eimg);

//fin init perso enemi
	
while(continuer == 1)	
	{  switch (gamemenu.p.player_nbr)
          {
			case 0 :
			 affiche_Menu(&gamemenu,screen1);
			 get_input_rep(&continuer,&input_rep);
			 Mise_a_jour_menu(&gamemenu,&input_rep,&continuer,screen1);
			 SDL_Flip(screen1);break;
                        case 1:
if (vrai==0)
{choixp= choix(screen);
switch (choixp.joueur)
{case 1 :p=p4;break;//azrek
case 2: p=p3;break;//black
case 3:p=p;break;//red

}
   vrai=1;}
                     // Game loop
while(!quitter) {

play=0;
//Display

 
affiche_back(b,screen);
afficherPerso( &p,screen);
afficherEnnemi(e,screen);
animerEnnemi(&e,screen);



deplacerIA(&e,p ) ;
//deplacer(&e);



SDL_Flip(screen);




//Input
SDL_PollEvent(&event);
switch (event.type)
         {
        // exit if the window is closed
	case SDL_QUIT: quitter = 1;
        break;

	


        case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
       {
            case SDLK_ESCAPE: quitter =1;
            break;
	
		case SDLK_m:
			resolution(&en,screen,O,m,t,anim );
            	break;

		case SDLK_g:
			while (run)
	 {
	    running=1,r=0 ;
	     SDL_PollEvent(&event_img);
           switch(event_img.type)
            {
              case SDL_QUIT:
                run = 0;
			  break ;
            }	
        	
      generate_afficher ( screen  , image ,&eimg,&alea) ;
	        

      s=solution_e (image );
			do{
			r=resolution_im(&running,&run);
			}while((r>4 || r<1) && running!=0) ;
			
			
      while(running){

				afficher_resultat (screen,s,r,&eimg) ;
			       SDL_WaitEvent(&event);
                     switch(event.type)
                       {
					     case SDL_QUIT :
                              running =0 ;
						      run=0 ;
					     break ;
                         case SDL_KEYDOWN :
						    
                             switch( event.key.keysym.sym )
                                  {
			                        case  SDLK_ESCAPE: 
			                           running= 0 ;
			                        break ;

						case SDLK_SPACE:
							run=0;
						break;
			                      }
						 break ;
                       }
                    } 	
   }
       
         


                   //----------------//
        case SDLK_n:
up=1;
break;


case SDLK_a:
if (p.dt==1)
{p.dt=3;

animerPerso(&p,screen);}
else
{if (p.dt==0)
{p.dt=2;

animerPerso(&p,screen);}}
break;


            case SDLK_LEFT:
 		p.dt=1;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;



            case SDLK_s:
 		
                deplacerPerso(&p,p.dt);
                 deplacerPerso(&p,p.dt);
                   animerPerso(&p,screen);
                break;
            case SDLK_RIGHT:
             p.dt=0;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;



		case SDLK_u:
			arduinoReadData(&ard);
	printf("%d",ard);
	switch(ard)
{
	case 0:
	p.dt=0;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
	break;
	case 1:
		p.dt=1;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
	break;
}
       
            }
break;
case SDL_KEYUP:
        switch(event.key.keysym.sym)
    {
    

    

    case SDLK_n:
        up=0;
        break; 

    
    }
       			break;
      }
                    
        if (up==1) saut(&p);

p.pos.y = p.pos.y   + p.vs ;
p.vs = p.vs + 10 ;
if (p.pos.y>=p.ground)
{   
    p.pos.y=p.ground;
    p.vs=0;
    p.up=0;
}
    
//col


c=collisionBB(p,e);
if (c==1)
{
	
	arduinoWriteData(x);
    p.v.valeur_vie++;}
if(p.v.valeur_vie==8)
p.v.valeur_vie=1;


	}


                          
			break;
                       

//-------------------perso 2---------------------------------

case 2:
p=p3;
        while(!q) {

play=0;
//Display

 
affiche_back(b,screen);
afficherPerso( &p,screen);
afficherPerso( &p2,screen);
afficherEnnemi(e,screen);
animerEnnemi(&e,screen);



deplacerIA(&e,p ) ;
//deplacer(&e);



SDL_Flip(screen);




//Input
SDL_PollEvent(&event);
switch (event.type)
         {
        // exit if the window is closed
	case SDL_QUIT: quitter = 1;
        break;

	


        case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
       {
            case SDLK_ESCAPE: quitter =1;
            break;
	
		
 
       
         


                   //----------------//
        case SDLK_n:
up=1;
break;


case SDLK_a:
if (p.dt==1)
{p.dt=3;

animerPerso(&p,screen);}
else
{if (p.dt==0)
{p.dt=2;

animerPerso(&p,screen);}}
break;


            case SDLK_LEFT:
 		p.dt=1;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;



            case SDLK_s:
 		
                deplacerPerso(&p,p.dt);
                 deplacerPerso(&p,p.dt);
                   animerPerso(&p,screen);
                break;
            case SDLK_RIGHT:
             p.dt=0;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;


 case SDLK_p:
up2=1;
break;


case SDLK_r:
if (p2.dt==1)
{p2.dt=3;

animerPerso(&p2,screen);}
else
{if (p2.dt==0)
{p2.dt=2;

animerPerso(&p2,screen);}}
break;


            case SDLK_k:
 		p2.dt=1;
                deplacerPerso(&p2,p2.dt);
                 
                   animerPerso(&p2,screen);
                break;



            case SDLK_i:
 		
                deplacerPerso(&p2,p2.dt);
                 deplacerPerso(&p2,p2.dt);
                   animerPerso(&p2,screen);
                break;
            case SDLK_l:
             p2.dt=0;
                deplacerPerso(&p2,p2.dt);
                 
                   animerPerso(&p2,screen);
                break;
       
		
            }
break;
case SDL_KEYUP:
        switch(event.key.keysym.sym)
    {
    

    

    case SDLK_n:
        up=0;
        break; 
case SDLK_SPACE:
up2=0;
break;

    
    }
       			break;
      }
                    
        if (up==1) saut(&p);

p.pos.y = p.pos.y   + p.vs ;
p.vs = p.vs + 10 ;
if (p.pos.y>=p.ground)
{   
    p.pos.y=p.ground;
    p.vs=0;
    p.up=0;
}
    if (up2==1) saut(&p2);

p2.pos.y = p2.pos.y   + p2.vs ;
p2.vs = p2.vs + 10 ;
if (p2.pos.y>=p2.ground)
{   
    p2.pos.y=p2.ground;
    p2.vs=0;
    p2.up=0;
}
//col


c=collisionBB(p,e);
if (c==1)
{
	
	arduinoWriteData(x);
    p.v.valeur_vie++;}
if(p.v.valeur_vie==8)
p.v.valeur_vie=1;


	}

break;






	}
}

//FREE

free_Menu(&gamemenu);
atexit(SDL_Quit);
freee(&en);
libereranimation(anim);
TTF_Quit();
SDL_Quit();


return 0 ;
}

