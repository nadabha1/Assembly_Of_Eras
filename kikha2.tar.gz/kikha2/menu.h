#ifndef FONCTION_H_INCLUDED
#include "input.h"
#define FONCTION_H_INCLUDED
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include <string.h>
#include <time.h>

typedef struct 
{
	SDL_Surface *settings_back;	
	SDL_Rect pos_settings;
	int volu,Vol,testvol; 
	SDL_Surface *img_soundminus,*img_soundplus,*img_soundon,*img_soundoff; 	
	SDL_Rect pos_soundminus,pos_soundplus,pos_soundon;
	
}sett;

typedef struct 
{
	SDL_Surface *button_back;
	SDL_Rect pos_button_back;
	SDL_Surface *img_curseurvol; 	
	SDL_Rect pos_curseurvol;
	SDL_Surface *button_fullscreenon;
	SDL_Surface *button_fullscreenoff;
	SDL_Rect pos_button_fullscreen;
	SDL_Surface *button_windowedon;
	SDL_Surface *button_windowedoff;
	SDL_Rect pos_button_windowed;
	int mode,affiche;
	
}sett2;

typedef struct {
	SDL_Rect pos_credit1,pos_credit2,pos_credit3,pos_credit4,pos_credit5,pos_credit6,pos_credit7,pos_credit8,pos_credit4_5;
	TTF_Font *font;
	SDL_Surface *texte_credit1,*texte_credit2,*texte_credit3,*texte_credit4, *texte_credit5,*texte_credit6,*texte_credit4_5;
	SDL_Color creditColor;
	char name1[40],name2[40],name3[40],name4[40],name5[40],name6[40],name4_5[40];
}credit;

typedef struct 
{
	SDL_Surface *fullscreen_back;
	SDL_Rect pos_fullscreen_back;
	SDL_Surface *menu_fullscreen_back;
	SDL_Rect pos_menu_fullscreen_back;
	int affiche_fullscreen,x,y;
}Fullscreen;

typedef struct 
{
	SDL_Surface *Load_back;
	SDL_Surface *multi_back;
	int affich_Load_multi_onetime;
	int player_nbr;
}play;

typedef struct 
{
	//animation ouverture
	int ouverture;
	SDL_Surface *ouverture_texte;
	SDL_Surface *ouverture_back;
	//----------
	Mix_Chunk *sound;
	//back menu amin
	SDL_Surface *menu_back[4];
	SDL_Rect pos_menu_back;
	//----------
	SDL_Surface *button_play_off,*button_play_on;
	SDL_Rect pos_button_play;
	SDL_Surface *button_exit_off,*button_exit_on;
	SDL_Rect pos_button_exit;
	SDL_Surface *button_credit_off,*button_credit_on;
	SDL_Rect pos_button_credit;
	SDL_Surface *button_settings_off,*button_settings_on;
	SDL_Rect pos_button_settings;
	int buttonaffich,arrowpos,soundcontrol,affichtest,affonetime;
	int buttonchoix,conteur1,conteur2;
	int menu,affichbackmenuonetime;
	SDL_Surface *credit_back;
	SDL_Rect pos_credit;
	//settings
	sett s;
	sett2 s2;
	credit c;
	Fullscreen f;
	play p;
}menu;





//INIT
void init_all_menu(menu *B,input *Input);
void init_ouverture(menu *m);
void initmusic();
void init_sound(menu *B);
void initialiser_background_menu(menu *B);
void initialiser_button_menu(menu *B);
void initialiser_background_play(menu *B);//here
void initialiser_background_settings_credit(menu *B);
void initialiser_volume(menu *m);
void initialiser_full_or_windowed_screen(menu *m);
void initText(menu *m);
void init_fullscreen_back(menu *m);
//------------

//AFFICHAGE
void affiche_Menu(menu *m, SDL_Surface* screen);
void affiche_MenuBackground(menu *m, SDL_Surface* screen);
void affiche_button_Menu(menu *m, SDL_Surface* screen);
void affiche_playBackground(menu *m, SDL_Surface* screen);
void affiche_settingsBackground(menu *m, SDL_Surface* screen);
void affiche_button_settings(menu *m, SDL_Surface* screen);
void affiche_creditBackground(menu *m, SDL_Surface* screen);
void affiche_volume(menu *m, SDL_Surface* screen);
void affiche_mode(menu *m, SDL_Surface* screen);
void affiche_fullscreen(menu *m, SDL_Surface* screen);
void affmenumulti(menu *m,SDL_Surface* screen);//here
void affiche_menu_animer(menu *m,SDL_Surface* screen);
void affiche_animation_ouverture(menu *m, SDL_Surface* screen);
//------------

//MAJ
void Mise_a_jour_menu(menu *m,input *inp,int *continuer,SDL_Surface* screen);
void Volume(menu *m,input input_rep);
void fullscreen_windowed(menu *m,input inp,SDL_Surface* screen);
void menuLoad(menu *m,input *inp);//here
void menu_multiplayer(menu *m,input *inp);
//------------

//free
void free_Menu(menu *m);
//------------
// enemi perso
typedef struct 
{
	SDL_Rect pos;
	SDL_Surface* enem[17];
	
int d,num;
	
}Ennemi;

typedef struct  
{
	SDL_Surface *vie[10];
	int valeur_vie;
	SDL_Rect pos_spr,pos;
}vie;
typedef struct 

{
SDL_Surface* background;  
SDL_Rect pos,posvie;
SDL_Surface *image[6][2]; 
int nump;
float vs;
int num1;//direction droit
int num2;//direction gauche
SDL_Surface* right[2];
SDL_Surface* left[2];
SDL_Surface* attack[2];
int time;
vie v;

int score;

int dt;//direction
int accel;
int vitesse;
int up,ground;
}Personne;

void initPerso4(Personne *p);
void initPerso2(Personne *p);
void initPerso3(Personne *p);
void initPerso(Personne *p);
void afficherPerso(Personne *p,SDL_Surface *screen);
void deplacerPerso(Personne*p,int dt);
void animerPerso(Personne *p, SDL_Surface *screen);
void saut(Personne *p);
void freePerso(Personne *p);
void initialiser_score2(vie *v);


typedef struct
{
	SDL_Rect pos1;

	SDL_Surface * img;
}back;






void initialiser_score(vie *v);
void update_score(vie *v);
void afficher_vie(vie v,SDL_Surface *screen);



void initialiserbackg(back *A);
void affiche_back(back B, SDL_Surface* screen);

void liberer(back B);


void initEnnemi(Ennemi*e);
void afficherEnnemi(Ennemi e, SDL_Surface * screen);
void animerEnnemi( Ennemi * e,SDL_Surface *screen);
void deplacer( Ennemi * e);
int collisionBB( Personne p, Ennemi e);
void deplacerIA(Ennemi * E,Personne p );
//void deplacerIA( Ennemi * e, SDL_Rect posPerso);

int arduinoWriteData(int x);
int arduinoReadData(int *x);


//------------enigme image---------------------------------
typedef struct 
{
 SDL_Surface * img;
 SDL_Rect 	p;
}enigmeim;

void init_enigme_im(enigmeim * e) ;
void  generate_afficher (SDL_Surface * screen  , char image [],enigmeim *e,int *alea) ;
 int solution_e (char image []) ;
int resolution_im(int * running,int *run);
void afficher_resultat (SDL_Surface * screen,int s,int r,enigmeim *en) ;
//------------------------------------------------------------------------

//------------------------------enigme texte---------------------------------


/**
* @struct enigme
* @brief struct for enigme
*/
typedef struct 
{
    char question[100];
    char rep1[100],rep2[100],rep3[100],rep4[100];
    int solution,alea,resolu;
    SDL_Surface *Question,*Rep1,*Rep2,*Rep3,*Rep4; /*!< variable de question et reponse. */
    SDL_Surface *correct,*wrong; /*!< image correct et wrong. */
    SDL_Rect question_Pos,rep1_Pos,rep2_Pos,rep3_Pos,rep4_Pos,position_correct, position_wrong;/*!< Rectangle*/
    SDL_Surface *img_back; /*!< image back. */
    SDL_Rect pos_back;/*!< Rectangle back*/
    Mix_Music* Music;
    TTF_Font *font;
     SDL_Color textColor;

}enigme;
/**
* @struct temps
* @brief struct for temps
*/
typedef struct
{
SDL_Surface *texte; /*!< texte. */
SDL_Rect position; /*!< Rectangle texte*/ 
TTF_Font *police ;
char entree[100];
int secondesEcoulees;
SDL_Color couleurBlanche;
time_t t1,t2;
int min, sec;
}temps;
//Volume
/**
* @struct volume
* @brief struct for volume
*/
typedef struct{

SDL_Surface *img_soundminus; /*!< image sound minus. */
SDL_Surface *img_soundplus; /*!< image sound plus. */
SDL_Rect pos_soundminus,pos_soundplus;/*!< Rectangle sound minus et sound plus*/ 
}volume;
/**
* @struct mute
* @brief struct for mute
*/
typedef struct{

SDL_Surface *img_soundon; /*!< image sound on. */
SDL_Surface *img_soundoff; /*!< image sound off. */
SDL_Surface *img_soundsupp; /*!< image sound supp. */
SDL_Rect pos_soundon; /*!< Rectangle sound on*/ 
}mute;
//------------------------------------------------------
void initialisation(enigme *e,volume *O,mute *m,temps *t,SDL_Surface *anim[]);
void afficher_temps_enigme(temps *t,SDL_Surface *screen,enigme *en);
void initialiser_temps_enigme(temps *t);
void alea_enig_fichier(enigme *en );
void blit_enig_fichier ( enigme *en, SDL_Surface* screen,mute m,volume O);
void init_enig_fichier( enigme * en);
void initialiser_volume_enigme(volume *O);
void initialiser_mute(mute *O);
void initanimation(SDL_Surface *anim[]);
void freee( enigme *en);
void resolution(enigme *en, SDL_Surface* screen,volume O,mute m,temps t,SDL_Surface* anim[]);
void afficheanimation(SDL_Surface* screen,enigme *B,SDL_Surface *anim[]);
void libereranimation(SDL_Surface *anim[]);
typedef struct{
int joueur;//1:rajel 2:mra
int input;//1:manette 2:clavier 
}choix_menu;
choix_menu choix(SDL_Surface *screen);


//--------------------------------------------BACKGROUND------------------------------










#endif
