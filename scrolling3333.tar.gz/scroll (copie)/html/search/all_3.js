var searchData=
[
  ['getpixel',['GetPixel',['../background_8c.html#a9ec79b71532402381966fc93325d3e52',1,'background.c']]]
];
