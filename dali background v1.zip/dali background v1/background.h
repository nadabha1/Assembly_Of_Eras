#ifndef background_h
#define background_h
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#define SCREEN_W 1366
#define SCREEN_H 678
#define SCREEN_W2 683
#define SCREEN_H2 678

typedef struct{
	SDL_Surface *imgback; 	
	SDL_Surface *imgbackm; 	
	SDL_Rect posback; 		
	SDL_Rect posbackm; 		
	SDL_Rect posback1;		
	SDL_Rect posbackm1;		
	SDL_Rect camera; 		
	SDL_Rect camera1; 		
	Mix_Music *son; 
SDL_Surface *anim[4];
  SDL_Rect posanim;
  int frame;
  int speed;		
}background;

void initBack (background *b);
void initBack1 (background *b);
void afficheBack (background b,SDL_Surface *ecran);
void afficheBack1 (background b,SDL_Surface *ecran);
void animeBackground(background *b);
SDL_Color  GetPixel(SDL_Surface *pSurface,int x,int y) ;
int collision_Parfaite(SDL_Surface *calque, SDL_Surface *perso, SDL_Rect posperso, int decalage, int d) ;
void scrolling (background *b,int direction);
void liberer(background b);
#endif
