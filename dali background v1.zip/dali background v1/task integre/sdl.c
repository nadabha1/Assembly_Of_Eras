#include "header.h"
//initializing the life meter
Life init_life(char life_name[])
{
    Life life;
    life.imageDeFond = IMG_Load(life_name);
    life.positionFond.x = 30;
    life.positionFond.y = 25;
    
    return life;
}
//initilizing the game audio window, window name 
void  init_SDL()
{
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1)
    {
        printf("%s", Mix_GetError());
    }

    SDL_Init(SDL_INIT_VIDEO);
    ecran = SDL_SetVideoMode(1280, 600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF| SDL_RESIZABLE);
    SDL_WM_SetCaption("dalou game", NULL);
    music = Mix_LoadMUS("menu.mp3");
    Mix_PlayMusic(music, -1);


}
//displaying the life meter
void aff_life(Life life)
{
    SDL_BlitSurface(life.imageDeFond, NULL, ecran, &life.positionFond);
}
