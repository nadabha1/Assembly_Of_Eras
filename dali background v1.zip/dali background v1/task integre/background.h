#ifndef Back_H
#define Back_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#define SCREEN_W 1280
#define SCREEN_H 600

struct Background
{
  SDL_Rect pos1;
  SDL_Rect pos2;
  SDL_Surface *img;
  SDL_Surface *anim[4];
  SDL_Rect posanim;
  int frame;
  int speed;
  int mouvement_personnage,mouvement_personnage1;
  SDL_Rect camera,posback1,posback2;
  SDL_Rect pos,posm,posm2;
};
typedef struct Background Background;

void initBack(Background *b);
void afficherBack(Background b,SDL_Surface *screen);
void animeBackground(Background *e);
//void scrolling_right(SDL_Surface *screen, Background *b);
//void scrolling_left(SDL_Surface *screen, Background *b);
SDL_Color GetPixel(SDL_Surface *pSurface,int x,int y);
int collisionPP(Player P,SDL_Surface *screen);
void scrolling(Background *b,int direction);
#endif
