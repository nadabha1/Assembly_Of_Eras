#ifndef player_H_INCLUDED
#define player_H_INCLUDED
#include "header.h"
#include "background.h"
#define JumpLimit 180
#define player_Default_Y 340
#define Gravity -5

typedef struct
{
    SDL_Surface *sprite[10] ;
    SDL_Rect position;
} entity;
entity init_entity(int x,int y);

typedef struct 
{
	int  up,left, right;
}Mouvement;
typedef struct
{
    entity e;
    Mouvement mouvement;
    int frame, air, sol;
    int direction;
    int mouse_clicked, target, vitesse;
} player;

SDL_Surface *masque;

int intervalleH1,intervalleH2,intervalleE1,intervalleE2,destination,continuer,position_absolue;
void Deplacer_player(int vitesse, player *player);
void jump(SDL_Event event, player *player);
void Acceleration(player *player, int acceleration);
void init_player(player *player);
void aff_player(player *player);
void getInput(SDL_Event event, int *continuer,Background *background,player *player);
void free_player(player *player);
void doKeyUp(SDL_Event event,player *player);
void doKeyDown(SDL_Event event,player *player);
void mouvement_mouse(player *player);
void Animation_Personnage(player *player);

#endif
