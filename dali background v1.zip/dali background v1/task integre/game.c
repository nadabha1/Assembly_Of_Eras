#include "header.h"
#include "menu.h"
#include "player.h"
#include "background.h"
#include "sdl.h"

animated an;

    /* writing text in mode Blended (optimal) */
  
    //initializing the game buttons
   

  
    //displaying the menu and animation
  
// main menu loop
 
//options menu

    //iniinitialisating SDL
  
//game loop
int Game()
{
    Background Bg;
    player player1;
    TTF_Init();
    
    
    Mix_FreeMusic(music);
    
    initBack(&Bg);
    life= init_life("life.png");
    
      destination =  0, continuer = 1,position_absolue =100;
    init_player(&player1);
    
    SDL_Event event;
    SDL_EnableKeyRepeat(100, 100);

// game music continue
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1)
    {
        printf("Problem playing music: %s", Mix_GetError());
    }
    music = Mix_LoadMUS("game.mp3");
    Mix_PlayMusic(music, -1);
    
// text score
   
    SDL_Surface *text = NULL;
    SDL_Color couleur = {255,0,0};
    TTF_Font *police = NULL;
    police = TTF_OpenFont("Ghost Writer - Demo.ttf",30);
    SDL_Rect position_text;
 /* ==> */  text = TTF_RenderText_Blended(police, "GAME SCORE   ", couleur);

 
    while (continuer)
    {
        afficherBack(Bg,ecran);
        aff_life(life);
        position_text.x = 30;//
  position_text.y = 0;//
  SDL_BlitSurface(text, NULL, ecran, &position_text);//score
        aff_player((&player1));
        getInput(event, &continuer, &Bg,&player1);
   
	animeBackground(&Bg);
        SDL_Flip(ecran);
        
  
 
   

}
    SDL_FreeSurface(Bg.img);
     SDL_FreeSurface(life.imageDeFond);
    
    free_player(&player1);
    
    TTF_Quit();
    SDL_FreeSurface(ecran);
          return destination;
} 




