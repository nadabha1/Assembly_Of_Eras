#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "background.h"
void initBack(Background *b)
{
  b->img=IMG_Load("bg1.jpg");
	if(b->img==NULL)
	   {
             printf("Unable to load image:%s\n",SDL_GetError());
	     return;
	   }
	b->pos1.x=0;
	b->pos1.y=0;
        b->pos2.w= 1366;
	b->pos2.h=768;
    b->posanim.x=0;
    b->posanim.y=0;
    b->frame=0;
    b->anim[0]=IMG_Load("1.png");
    b->anim[1]=IMG_Load("1.png");
    b->anim[2]=IMG_Load("2.png");
    b->anim[3]=IMG_Load("3.png");
   // b->speed=500;
    b->camera.x=0;
    b->camera.y=0;
    b->camera.w=SCREEN_W;
    b->camera.h=SCREEN_H;

}
void afficherBack(Background b,SDL_Surface *screen)
{
  SDL_BlitSurface(b.img,&b.camera,screen,&b.pos1);
  SDL_BlitSurface(b.anim[b.frame],NULL,screen,&b.posanim);
}
void animeBackground(Background *e)
{   
    if(e->frame==3)
        e->frame=0;
    else e->frame++;
}
/*
 void scrolling(Background *b, int direction)
{
switch(direction)
 {
   
   case 1:
    if (event.key.keysym.sym == SDLK_LEFT)
    {
        b->camera.x++;
    }                         //move right 
     
   break; 
   case 2://move left 
     b->camera.x--;
   break;
   case 3://move down
     b->camera.y--;
   break;
   case 4://move up
     b->camera.y++;
   break;
  }
}
*/
SDL_Color GetPixel(SDL_Surface *pSurface,int x,int y)
{
  SDL_Color color;
  Uint32 col=0;
  char* pPosition=(char*)pSurface->pixels;
  pPosition+=(pSurface->pitch*y);
  pPosition+=(pSurface->format->BytesPerPixel*x);
  memcpy(&col,pPosition,pSurface->format->BytesPerPixel);
  SDL_GetRGB(col,pSurface->format,&color.r,&color.g,&color.b);
  return(color);
}
int collisionPP(Player P,SDL_Surface *screen)
{ 
  int collision=0,i=0;
  SDL_Color Color_obs;
  SDL_Rect pos[8];
  Color_obs.r=0;
  Color_obs.g=0;
  Color_obs.b=0;
  SDL_Surface *Bmask;
  Bmask=SDL_LoadBMP("mask.bmp");
  pos[0].x=P.x;
  pos[0].y=P.y;
  pos[1].x=P.x+w/2;
  pos[1].y=P.y;

  pos[2].x=P.x+w;
  pos[2].y=P.y;
  pos[3].x=P.x;
  pos[3].y=P.y+H/2;
  pos[4].x=P.x;
  pos[4].y=P.y+H;
  pos[5].x=P.x+W/2;
  pos[5].y=P.y+H;
  pos[6].x=P.x+W;
  pos[6].y=P.y+H;
  pos[7].x=P.x+w;
  pos[7].y=P.y+H/2;
  //SDL_GetRGB(GetPixel(&pSurface,x,y),P->format,&Color_obs.r,&Color_obs.g,&Color_obs.b);
  while((i<8)&&(collision==0))
  { 
    Color_obs=GetPixel(Bmask,pos[i].x,pos[i].y);
    i++;
    if(Color_obs.r==0 && Color_obs.g==0 && Color_obs.b==0)
      {collision=1;}
  }
  return collision;
}
*/
