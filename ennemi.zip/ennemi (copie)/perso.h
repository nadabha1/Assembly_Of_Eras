#ifndef perso_H_INCLUDED
#define perso_H_INCLUDED
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>



/*typedef struct 
{SDL_Surface vimg[4];
SDL_Rect posvie;
int nb;
}vie;*/
typedef struct 

{
SDL_Surface* background;  
SDL_Rect pos,posvie;
SDL_Surface *image[6][2]; 
int nump;
float vs;
int num1;//direction droit
int num2;//direction gauche
SDL_Surface* right[2];
SDL_Surface* left[2];
SDL_Surface* attack[2];
int time;
SDL_Surface *vimg[3];
int vie;
int score;

int dt;//direction
int accel;
int vitesse;
int up,ground;
}Personne;


void affichertemp (Uint32 *temps,SDL_Surface *screen,TTF_Font *police);


void initPerso(Personne *p);
void afficherPerso(Personne *p,SDL_Surface *screen);
void deplacerPerso(Personne*p,int dt);
void animerPerso(Personne *p, SDL_Surface *screen);
void saut(Personne *p);
void freePerso(Personne *p);

#endif
