#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "perso.h"
int main()
{
    SDL_Surface *ecran =NULL;
    
    SDL_Rect positionecran;
    char pause;

Personne p1,p2;
int up1,up2;
    int continuer =1;


    SDL_Event event;
    
    positionecran.x=-10;
    positionecran.y=-10;
  
    SDL_Init(SDL_INIT_VIDEO);
initPerso(&p1);
initPerso2(&p2);
p2.pos.x+=40;

    ecran = SDL_SetVideoMode(881, 536, 32, SDL_HWSURFACE );
    while (continuer)
    {
     SDL_WaitEvent(&event);
       afficherPerso( &p1,ecran);
        afficherPerso( &p2,ecran);
        switch (event.type)
        {
        case SDL_QUIT:
            continuer=0;
            break;
        case SDL_KEYDOWN:
            switch (event.key.keysym.sym)
            {
            case SDLK_ESCAPE:
                continuer=0;
                break;
        case SDLK_n:
up1=1;
break;


case SDLK_a:
if (p1.dt==1)
{p1.dt=3;

animerPerso(&p1,ecran);}
else
{if (p1.dt==0)
{p1.dt=2;

animerPerso(&p1,ecran);}}
break;


            case SDLK_LEFT:
 		p1.dt=1;
                deplacerPerso(&p1,p1.dt);
                 
                   animerPerso(&p1,ecran);
                break;



            case SDLK_s:
 		
                deplacerPerso(&p1,p1.dt);
                 deplacerPerso(&p1,p1.dt);
                   animerPerso(&p1,ecran);
                break;
            case SDLK_RIGHT:
             p1.dt=0;
                deplacerPerso(&p1,p1.dt);
                 
                   animerPerso(&p1,ecran);
                break;
       

        case SDLK_p:
up2=1;
break;


case SDLK_r:
if (p2.dt==1)
{p2.dt=3;

animerPerso(&p2,ecran);}
else
{if (p2.dt==0)
{p2.dt=2;

animerPerso(&p2,ecran);}}
break;


            case SDLK_k:
 		p2.dt=1;
                deplacerPerso(&p2,p2.dt);
                 
                   animerPerso(&p2,ecran);
                break;



            case SDLK_i:
 		
                deplacerPerso(&p2,p2.dt);
                 deplacerPerso(&p2,p2.dt);
                   animerPerso(&p2,ecran);
                break;
            case SDLK_m:
             p2.dt=0;
                deplacerPerso(&p2,p2.dt);
                 
                   animerPerso(&p2,ecran);
                break;
       
            }
break;
case SDL_KEYUP:
switch (event.key.keysym.sym)
    {
    

    

    case SDLK_n:
        up1=0;
        break; 

    case SDLK_p:
        up2=0;
        break; 


      
    
    }
       			break;
      
                    
        }if (up1==1) saut(&p1);

p1.pos.y = p1.pos.y   + p1.vs ;
p1.vs = p1.vs + 10 ;
if (p1.pos.y>=p1.ground)
{   
    p1.pos.y=p1.ground;
    p1.vs=0;
    p1.up=0;
}if (up2==1) saut(&p2);

p2.pos.y = p2.pos.y   + p2.vs ;
p2.vs = p2.vs + 10 ;
if (p2.pos.y>=p2.ground)
{   
    p2.pos.y=p2.ground;
    p2.vs=0;
    p2.up=0;
}
    }

    freePerso(&p1);
    freePerso(&p2);
 
    return 0;
}

