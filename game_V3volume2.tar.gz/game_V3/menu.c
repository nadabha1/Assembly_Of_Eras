#include "menu.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>


//INIT
void init_all_menu(menu *B,input *Input)
{
	init_ouverture(B);
	initmusic();
	initialiser_background_menu(B);
	init_input(Input);
	initialiser_button_menu(B);
	init_sound(B);
	initialiser_background_play(B);
	initialiser_background_settings_credit(B);
	initialiser_volume(B);
	initialiser_full_or_windowed_screen(B);
	initText(B);
	init_fullscreen_back(B);
	B->buttonaffich=0;
	B->buttonchoix=0;
	B->arrowpos=0;
	B->soundcontrol=0;
	B->menu=-1;
	B->affichtest=0;
	B->affonetime=0;
	B->affichbackmenuonetime=0;
}

void init_ouverture(menu *m)
{
	m->ouverture_texte=IMG_Load("RES/Menu/animation ouverture/LOGO OUVERTURE.png");
	m->ouverture_back=IMG_Load("RES/Menu/animation ouverture/black back.png");
	m->ouverture=0;
}


void initText(menu *m)
{
m->c.pos_credit1.x=550;
m->c.pos_credit2.x=700;
m->c.pos_credit3.x=600;
m->c.pos_credit4.x=600;
m->c.pos_credit4_5.x=600;
m->c.pos_credit5.x=600;
m->c.pos_credit6.x=600;
m->c.pos_credit7.x=600;
m->c.pos_credit8.x=600;

m->c.pos_credit1.y=320;
m->c.pos_credit2.y=320;
m->c.pos_credit3.y=370;
m->c.pos_credit4.y=420;
m->c.pos_credit4_5.y=470;
m->c.pos_credit5.y=520;
m->c.pos_credit6.y=570;


m->c.creditColor.r=255;
m->c.creditColor.g=255;
m->c.creditColor.b=255;
m->c.font=TTF_OpenFont("RES/Font/1.ttf",60);
strcpy(m->c.name1,"Team");
strcpy(m->c.name2,"Members");
strcpy(m->c.name3,"Mahdi Koubaa");
strcpy(m->c.name4,"Ahmed Trabelsi");
strcpy(m->c.name4_5,"Nada Belhadjamor");
strcpy(m->c.name5,"Mohamed Ali Hamraoui");
strcpy(m->c.name6,"Aziz Ben Ajmia");
m->c.texte_credit1=TTF_RenderText_Blended(m->c.font,m->c.name1,m->c.creditColor);
m->c.texte_credit2=TTF_RenderText_Blended(m->c.font,m->c.name2,m->c.creditColor);
m->c.texte_credit3=TTF_RenderText_Blended(m->c.font,m->c.name3,m->c.creditColor);
m->c.texte_credit4=TTF_RenderText_Blended(m->c.font,m->c.name4,m->c.creditColor);
m->c.texte_credit4_5=TTF_RenderText_Blended(m->c.font,m->c.name4_5,m->c.creditColor);
m->c.texte_credit5=TTF_RenderText_Blended(m->c.font,m->c.name5,m->c.creditColor);
m->c.texte_credit6=TTF_RenderText_Blended(m->c.font,m->c.name6,m->c.creditColor);

}

//--------------
void init_sound(menu *B)
{
	B->sound=Mix_LoadWAV("RES/Menu/sound/Click De  Souris.wav");
}
//--------------
void initmusic()
{
	Mix_Music *music;
	if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)

		{printf("NO AUDIO %s\n",Mix_GetError());}

 
	Mix_VolumeMusic(20);
	music = Mix_LoadMUS("RES/menu son.mp3"); //load the music 
	
	Mix_PlayMusic(music,-1); //play music 
}

//-------------

void init_fullscreen_back(menu *m)
{
	m->f.fullscreen_back=IMG_Load("RES/Menu/Fullscreen/Fullscreen back.gif");

	m->f.pos_fullscreen_back.x=0;
	m->f.pos_fullscreen_back.y=0;
	
	m->f.affiche_fullscreen=0;
	m->f.x=0;
	m->f.y=0;

}

void initialiser_background_menu(menu *m)
{
	int i;
	char filename[43];
	for(i=0;i<4;i++)
	{
		sprintf(filename,"RES/Menu/menu anim/menu %d.png",i); 
		m->menu_back[i] = IMG_Load(filename);
	}

	m->pos_menu_back.x=0;
	m->pos_menu_back.y=0;
	m->pos_menu_back.w=0;
	m->pos_menu_back.h=0;

	m->conteur1=0;
	m->conteur2=0;


	
}

void initialiser_volume(menu *m)  		
{
m->s.img_soundminus= IMG_Load("RES/Menu/Settings/soundminus.png");
m->s.img_soundplus= IMG_Load("RES/Menu/Settings/soundplus.png");


m->s.pos_soundminus.x=579;
m->s.pos_soundminus.y=355;
m->s.pos_soundminus.w=88;
m->s.pos_soundminus.h=70;

m->s.pos_soundplus.x=906;
m->s.pos_soundplus.y=355;
m->s.pos_soundplus.w=88;
m->s.pos_soundplus.h=70;

m->s.img_soundon= IMG_Load("RES/Menu/Settings/soundon.png");
m->s.img_soundoff= IMG_Load("RES/Menu/Settings/soundoff.png");


m->s.pos_soundon.x=542;
m->s.pos_soundon.y=431;
m->s.pos_soundon.w=88;
m->s.pos_soundon.h=70;

m->s2.img_curseurvol= IMG_Load("RES/Menu/Settings/sound curser.png");

m->s2.pos_curseurvol.x=685;
m->s2.pos_curseurvol.y=373;
m->s2.pos_curseurvol.w=10;
m->s2.pos_curseurvol.h=30;

m->s.volu=20;
m->s.Vol=20;
m->s.testvol=0;


}

void initialiser_full_or_windowed_screen(menu *m)  	
{
	m->s2.button_fullscreenon= IMG_Load("RES/Menu/Settings/Fullscreenon.png");
	m->s2.button_fullscreenoff= IMG_Load("RES/Menu/Settings/Fullscreenoff.png");

	m->s2.pos_button_fullscreen.x=581;
	m->s2.pos_button_fullscreen.y=538;
	m->s2.pos_button_fullscreen.w=83;
	m->s2.pos_button_fullscreen.h=67;

	m->s2.button_windowedon= IMG_Load("RES/Menu/Settings/Windowed on.png");
	m->s2.button_windowedoff= IMG_Load("RES/Menu/Settings/Windowed off.png");

	m->s2.pos_button_windowed.x=905;
	m->s2.pos_button_windowed.y=538;
	m->s2.pos_button_windowed.w=83;
	m->s2.pos_button_windowed.h=67;
	
	m->s2.button_back=IMG_Load("RES/Menu/Settings/Back.png");

	m->s2.pos_button_back.x=387;
	m->s2.pos_button_back.y=236;
	m->s2.pos_button_back.w=179;
	m->s2.pos_button_back.h=76;

	m->s2.mode=0;
	m->s2.affiche=0;
}

void initialiser_background_play(menu *m)//here
{
	m->p.Load_back=IMG_Load("RES/Menu/menu play/Loadgame menu.png");
	m->p.multi_back=IMG_Load("RES/Menu/menu play/multiplayers menu.png");
	m->p.affich_Load_multi_onetime=0;
	m->p.player_nbr=0;


}

void initialiser_background_settings_credit(menu *B)
{
	(*B).credit_back=IMG_Load("RES/Menu/credit/menu credit.png");
	(*B).s.settings_back=IMG_Load("RES/Menu/Settings/settings back.png");

	(*B).s.pos_settings.x=375;
	(*B).s.pos_settings.y=200;
	(*B).s.pos_settings.w=873;
	(*B).s.pos_settings.h=482;
	(*B).pos_credit.x=375;
	(*B).pos_credit.y=200;
	(*B).pos_credit.w=873;
	(*B).pos_credit.h=482;

}

void initialiser_button_menu(menu *B)
{
	(*B).button_play_off=IMG_Load("RES/Menu/Buttons/PLAY.png");
	(*B).button_play_on=IMG_Load("RES/Menu/Buttons/PLAY1.png");
	(*B).pos_button_play.x=200;
	(*B).pos_button_play.y=360;
	(*B).pos_button_play.w=311;
	(*B).pos_button_play.h=135;

	(*B).button_settings_off=IMG_Load("RES/Menu/Buttons/OPTIONS.png");
	(*B).button_settings_on=IMG_Load("RES/Menu/Buttons/OPTIONS1.png");
	(*B).pos_button_settings.x=200;
	(*B).pos_button_settings.y=430;
	(*B).pos_button_settings.w=311;
	(*B).pos_button_settings.h=135;

	(*B).button_credit_off=IMG_Load("RES/Menu/Buttons/CREDIT.png");
	(*B).button_credit_on=IMG_Load("RES/Menu/Buttons/CREDIT1.png");
	(*B).pos_button_credit.x=200;
	(*B).pos_button_credit.y=500;
	(*B).pos_button_credit.w=311;
	(*B).pos_button_credit.h=135;

	(*B).button_exit_off=IMG_Load("RES/Menu/Buttons/EXIT.png");
	(*B).button_exit_on=IMG_Load("RES/Menu/Buttons/EXIT1.png");
	(*B).pos_button_exit.x=200;
	(*B).pos_button_exit.y=570;
	(*B).pos_button_exit.w=311;
	(*B).pos_button_exit.h=135;

}
//AFFICHAGE
void affiche_Menu(menu *m, SDL_Surface* screen)
{
	affiche_animation_ouverture(m,screen);
	affiche_MenuBackground(m,screen);
	affiche_button_Menu(m,screen);
	affiche_playBackground(m,screen);
	affiche_button_settings(m,screen);
	affiche_creditBackground(m,screen);
	affiche_fullscreen(m,screen);
	affmenumulti(m,screen);
}

void affiche_animation_ouverture(menu *m, SDL_Surface* screen)//here
{
	if(m->ouverture<200)
		{
		 SDL_BlitSurface(m->ouverture_texte,NULL,screen,&m->pos_menu_back);
		 m->ouverture++;
		}
	else if (m->ouverture<=250)
		{
		 SDL_BlitSurface(m->ouverture_back,NULL,screen,&m->pos_menu_back);
		 m->ouverture++;
		}
	if(m->ouverture==249)
		{m->menu=0;}
	
}

void affiche_menu_animer(menu *m,SDL_Surface* screen)
{
	if(m->conteur1==3)
		m->conteur1=0;
	else if(m->conteur2==25)
		{
		 m->conteur1++;
		 m->conteur2=0;
		}
	else
		m->conteur2++;
	SDL_BlitSurface(m->menu_back[m->conteur1],NULL,screen,&m->pos_menu_back);
	
	
		
	
}

void affiche_MenuBackground(menu *m, SDL_Surface* screen)
{
	if((m->buttonaffich==0)&&(m->menu==0))
	{
		m->affichtest=0;
		
		affiche_menu_animer(m,screen);
	}
}

void affiche_playBackground(menu *m, SDL_Surface* screen)
{
	if(m->menu==1)
	{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->p.Load_back,NULL,screen,&m->s.pos_settings);//here
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);
		
	}
}

void affiche_settingsBackground(menu *m, SDL_Surface* screen)
{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->s.settings_back,NULL,screen,&m->s.pos_settings);
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);
		
}

void affiche_volume(menu *m, SDL_Surface* screen)
{
	int i;
	if(m->s.testvol!=m->s.volu)
	{
	if(m->f.x==150)
	{
		i=150;
	}
	else
		i=0;
	if(m->s.volu==0)
		{m->s2.pos_curseurvol.x=685+i;
		
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==20)
		{m->s2.pos_curseurvol.x=725+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==40)
		{m->s2.pos_curseurvol.x=765+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==60)
		{m->s2.pos_curseurvol.x=800+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==80)
		{m->s2.pos_curseurvol.x=840+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	if(m->s.volu==100)
		{m->s2.pos_curseurvol.x=880+i;
		m->affichtest=0;
		affiche_settingsBackground(m,screen);
		SDL_BlitSurface(m->s2.img_curseurvol,NULL,screen,&m->s2.pos_curseurvol);}
	m->s.testvol=m->s.volu;
	m->s2.affiche=0;
	}

		SDL_BlitSurface(m->s.img_soundminus,NULL,screen,&m->s.pos_soundminus);
		SDL_BlitSurface(m->s.img_soundplus,NULL,screen,&m->s.pos_soundplus);
	if (m->s.volu>0)
		{
		 SDL_BlitSurface(m->s.img_soundon,NULL,screen,&m->s.pos_soundon);
		}
	else
		{
		 SDL_BlitSurface(m->s.img_soundoff,NULL,screen,&m->s.pos_soundon);
		}
}

void affiche_mode(menu *m, SDL_Surface* screen)
{

 if(m->s2.mode==0)
	{
	 SDL_BlitSurface(m->s2.button_windowedon,NULL,screen,&m->s2.pos_button_windowed);
	 SDL_BlitSurface(m->s2.button_fullscreenoff,NULL,screen,&m->s2.pos_button_fullscreen);
	}
 else if(m->s2.mode==1)
	{
	 SDL_BlitSurface(m->s2.button_windowedoff,NULL,screen,&m->s2.pos_button_windowed);
	 SDL_BlitSurface(m->s2.button_fullscreenon,NULL,screen,&m->s2.pos_button_fullscreen);
	}

}


void affiche_button_settings(menu *m, SDL_Surface* screen)
{
	if(m->menu==2)
	{
		if(m->s2.affiche==0)
		{
			m->s2.affiche=1;
			affiche_volume(m,screen);
			affiche_mode(m,screen);
		}
		
	}
}

void affiche_creditBackground(menu *m, SDL_Surface* screen)
{
	if((m->menu==3))
	{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->credit_back,NULL,screen,&m->s.pos_settings);
		SDL_BlitSurface(m->c.texte_credit1,NULL,screen,&m->c.pos_credit1);
		SDL_BlitSurface(m->c.texte_credit2,NULL,screen,&m->c.pos_credit2);
		SDL_BlitSurface(m->c.texte_credit3,NULL,screen,&m->c.pos_credit3);
		SDL_BlitSurface(m->c.texte_credit4,NULL,screen,&m->c.pos_credit4);
		SDL_BlitSurface(m->c.texte_credit4_5,NULL,screen,&m->c.pos_credit4_5);
		SDL_BlitSurface(m->c.texte_credit5,NULL,screen,&m->c.pos_credit5);
		SDL_BlitSurface(m->c.texte_credit6,NULL,screen,&m->c.pos_credit6);
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);
		
	}
}


void affmenumulti(menu *m,SDL_Surface* screen)
{
	if((m->menu==5))
	{
		affiche_menu_animer(m,screen);
		SDL_BlitSurface(m->p.multi_back,NULL,screen,&m->s.pos_settings);
		SDL_BlitSurface(m->s2.button_back,NULL,screen,&m->s2.pos_button_back);	
	}
	
}

void affiche_button_Menu(menu *m, SDL_Surface* screen)
{	
	if(m->menu==0)
	{
	
			affiche_menu_animer(m,screen);
			SDL_BlitSurface(m->button_play_off,NULL,screen,&m->pos_button_play);
			SDL_BlitSurface(m->button_exit_off,NULL,screen,&m->pos_button_exit);
			SDL_BlitSurface(m->button_credit_off,NULL,screen,&m->pos_button_credit);
			SDL_BlitSurface(m->button_settings_off,NULL,screen,&m->pos_button_settings);
		
	if(m->buttonchoix==1)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_play_on,NULL,screen,&m->pos_button_play);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	else
	if(m->buttonchoix==2)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_settings_on,NULL,screen,&m->pos_button_settings);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	else
	if(m->buttonchoix==3)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_credit_on,NULL,screen,&m->pos_button_credit);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	else
	if(m->buttonchoix==4)
		{
			if(m->affonetime==1)
			{
			SDL_BlitSurface(m->button_exit_on,NULL,screen,&m->pos_button_exit);
			m->buttonaffich=0;
			m->buttonchoix=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
			}
		}
	if(m->arrowpos==1)
		{
			SDL_BlitSurface(m->button_play_on,NULL,screen,&m->pos_button_play);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}
	else
	if(m->arrowpos==2)
		{
			SDL_BlitSurface(m->button_settings_on,NULL,screen,&m->pos_button_settings);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}
	else
	if(m->arrowpos==3)
		{
			SDL_BlitSurface(m->button_credit_on,NULL,screen,&m->pos_button_credit);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}
	else
	if(m->arrowpos==4)
		{
			
			SDL_BlitSurface(m->button_exit_on,NULL,screen,&m->pos_button_exit);
			m->buttonaffich=0;
			if(m->soundcontrol==0)
				{
					Mix_PlayChannel(-1,m->sound,0);
					m->soundcontrol=1;
				}
		}

	}		
	
}

void affiche_fullscreen(menu *m,SDL_Surface* screen)
{
	if((m->f.affiche_fullscreen==0)&&(m->s2.mode==1))
	{
		SDL_BlitSurface(m->f.fullscreen_back,NULL,screen,&m->f.pos_fullscreen_back);
		m->f.affiche_fullscreen=1;
	}
}

//MAJ
void menu_multiplayer(menu *m,input *inp)//here
{
	if(pos_mouse(*inp,603+m->f.x,1000+m->f.x,290+m->f.y,423+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->p.player_nbr=1;
		m->menu=-1;
	}
	if(pos_mouse(*inp,603+m->f.x,1000+m->f.x,476+m->f.y,609+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->p.player_nbr=2;
		m->menu=-1;
	}
}

void menuLoad(menu *m,input *inp)//here
{
	if(pos_mouse(*inp,641+m->f.x,947+m->f.x,290+m->f.y,423+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->menu=5;
		m->p.affich_Load_multi_onetime=0;
	}
	if(pos_mouse(*inp,641+m->f.x,947+m->f.x,476+m->f.y,609+m->f.y)==1)
	{
		inp->mouse.click=0;
		m->menu=5;
		m->p.affich_Load_multi_onetime=0;
	}
}

void Volume(menu *m,input input_rep)
{
	
	if((input_rep.keys.n==1)||(pos_mouse(input_rep,m->s.pos_soundminus.x,m->s.pos_soundminus.x+m->s.pos_soundminus.w,m->s.pos_soundminus.y,m->s.pos_soundminus.y+m->s.pos_soundminus.h)))
		{if(m->s.volu>0)
     		     {m->s.volu=m->s.volu-20;
       		    Mix_VolumeMusic(m->s.volu);
			SDL_Delay(200);}
			}
	if((input_rep.keys.b==1)||(pos_mouse(input_rep,m->s.pos_soundplus.x,m->s.pos_soundplus.x+m->s.pos_soundplus.w,m->s.pos_soundplus.y,m->s.pos_soundplus.y+m->s.pos_soundplus.h)))
		{ if(m->s.volu<100)
     		     {m->s.volu=m->s.volu+20;
       		    Mix_VolumeMusic(m->s.volu);
			SDL_Delay(200);}
			}
	if((input_rep.keys.m==1)||(pos_mouse(input_rep,m->s.pos_soundon.x,m->s.pos_soundon.x+m->s.pos_soundon.w,m->s.pos_soundon.y,m->s.pos_soundon.y+m->s.pos_soundon.h)))
		{if(m->s.volu>0)
     		     {Mix_VolumeMusic(0);
		      m->s.Vol=m->s.volu;
		      m->s.volu=0;
			SDL_Delay(200);}
		   else 
     		     {m->s.volu=m->s.Vol;
       		    Mix_VolumeMusic(m->s.volu);
			SDL_Delay(200);
			}
			}
}

void fullscreen_windowed(menu *m,input inp,SDL_Surface* screen)
{
	if((pos_mouse(inp,m->s2.pos_button_windowed.x,m->s2.pos_button_windowed.x+m->s2.pos_button_windowed.w,m->s2.pos_button_windowed.y,m->s2.pos_button_windowed.y+m->s2.pos_button_windowed.h)==1)&&(m->s2.mode==1))
		{
			m->s2.mode=0;
			m->affichtest=0;
			screen = SDL_SetVideoMode(1620, 880,32, SDL_HWSURFACE| SDL_DOUBLEBUF);
			m->f.affiche_fullscreen=0;
			m->f.x=-150;
			m->f.y=-100;
			
			m->c.pos_credit1.x=m->c.pos_credit1.x+m->f.x;
			m->c.pos_credit2.x=m->c.pos_credit2.x+m->f.x;
			m->c.pos_credit3.x=m->c.pos_credit3.x+m->f.x;
			m->c.pos_credit4.x=m->c.pos_credit4.x+m->f.x;
			m->c.pos_credit4_5.x=m->c.pos_credit4_5.x+m->f.x;
			m->c.pos_credit5.x=m->c.pos_credit5.x+m->f.x;
			m->c.pos_credit6.x=m->c.pos_credit6.x+m->f.x;
			
			m->c.pos_credit1.y=m->c.pos_credit1.y+m->f.y;
			m->c.pos_credit2.y=m->c.pos_credit2.y+m->f.y;
			m->c.pos_credit3.y=m->c.pos_credit3.y+m->f.y;
			m->c.pos_credit4.y=m->c.pos_credit4.y+m->f.y;
			m->c.pos_credit4_5.y=m->c.pos_credit4_5.y+m->f.y;
			m->c.pos_credit5.y=m->c.pos_credit5.y+m->f.y;
			m->c.pos_credit6.y=m->c.pos_credit6.y+m->f.y;
			
			m->s.pos_soundminus.x=m->s.pos_soundminus.x+m->f.x;
			m->s.pos_soundminus.y=m->s.pos_soundminus.y+m->f.y;

			m->s.pos_soundplus.x=m->s.pos_soundplus.x+m->f.x;
			m->s.pos_soundplus.y=m->s.pos_soundplus.y+m->f.y;

			m->s.pos_soundon.x=m->s.pos_soundon.x+m->f.x;
			m->s.pos_soundon.y=m->s.pos_soundon.y+m->f.y;

			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;//here
			m->s2.pos_curseurvol.y=m->s2.pos_curseurvol.y+m->f.y;
			
			m->s2.pos_button_fullscreen.x=m->s2.pos_button_fullscreen.x+m->f.x;
			m->s2.pos_button_fullscreen.y=m->s2.pos_button_fullscreen.y+m->f.y;

			m->s2.pos_button_windowed.x=m->s2.pos_button_windowed.x+m->f.x;
			m->s2.pos_button_windowed.y=m->s2.pos_button_windowed.y+m->f.y;
		
			m->s2.pos_button_back.x=m->s2.pos_button_back.x+m->f.x;
			m->s2.pos_button_back.y=m->s2.pos_button_back.y+m->f.y;

			m->s.pos_settings.x=m->s.pos_settings.x+m->f.x;
			m->s.pos_settings.y=m->s.pos_settings.y+m->f.y;

			m->pos_credit.x=m->pos_credit.x+m->f.x;
			m->pos_credit.y=m->pos_credit.y+m->f.y;

			m->pos_button_play.x=m->pos_button_play.x+m->f.x;
			m->pos_button_play.y=m->pos_button_play.y+m->f.y;

			m->pos_button_exit.x=m->pos_button_exit.x+m->f.x;
			m->pos_button_exit.y=m->pos_button_exit.y+m->f.y;

			m->pos_button_credit.x=m->pos_button_credit.x+m->f.x;
			m->pos_button_credit.y=m->pos_button_credit.y+m->f.y;

			m->pos_button_settings.x=m->pos_button_settings.x+m->f.x;
			m->pos_button_settings.y=m->pos_button_settings.y+m->f.y;
			
			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;
			m->s2.pos_curseurvol.y=373;


		}
	else
	if((pos_mouse(inp,m->s2.pos_button_fullscreen.x,m->s2.pos_button_fullscreen.x+m->s2.pos_button_fullscreen.w,m->s2.pos_button_fullscreen.y,m->s2.pos_button_fullscreen.y+m->s2.pos_button_fullscreen.h)==1)&&(m->s2.mode==0))//here
		{
			m->s2.mode=1;
			m->affichtest=0;
			screen = SDL_SetVideoMode(1920,1080,32, SDL_FULLSCREEN| SDL_DOUBLEBUF);
			m->f.x=150;
			m->f.y=100;			
			
			m->c.pos_credit1.x=m->c.pos_credit1.x+m->f.x;
			m->c.pos_credit2.x=m->c.pos_credit2.x+m->f.x;
			m->c.pos_credit3.x=m->c.pos_credit3.x+m->f.x;
			m->c.pos_credit4.x=m->c.pos_credit4.x+m->f.x;
			m->c.pos_credit4_5.x=m->c.pos_credit4_5.x+m->f.x;
			m->c.pos_credit5.x=m->c.pos_credit5.x+m->f.x;
			m->c.pos_credit6.x=m->c.pos_credit6.x+m->f.x;
			
			m->c.pos_credit1.y=m->c.pos_credit1.y+m->f.y;
			m->c.pos_credit2.y=m->c.pos_credit2.y+m->f.y;
			m->c.pos_credit3.y=m->c.pos_credit3.y+m->f.y;
			m->c.pos_credit4.y=m->c.pos_credit4.y+m->f.y;
			m->c.pos_credit4_5.y=m->c.pos_credit4_5.y+m->f.y;
			m->c.pos_credit5.y=m->c.pos_credit5.y+m->f.y;
			m->c.pos_credit6.y=m->c.pos_credit6.y+m->f.y;
			
			m->s.pos_soundminus.x=m->s.pos_soundminus.x+m->f.x;
			m->s.pos_soundminus.y=m->s.pos_soundminus.y+m->f.y;

			m->s.pos_soundplus.x=m->s.pos_soundplus.x+m->f.x;
			m->s.pos_soundplus.y=m->s.pos_soundplus.y+m->f.y;

			m->s.pos_soundon.x=m->s.pos_soundon.x+m->f.x;
			m->s.pos_soundon.y=m->s.pos_soundon.y+m->f.y;

			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;//here
			m->s2.pos_curseurvol.y=m->s2.pos_curseurvol.y+m->f.y;
			
			m->s2.pos_button_fullscreen.x=m->s2.pos_button_fullscreen.x+m->f.x;
			m->s2.pos_button_fullscreen.y=m->s2.pos_button_fullscreen.y+m->f.y;

			m->s2.pos_button_windowed.x=m->s2.pos_button_windowed.x+m->f.x;
			m->s2.pos_button_windowed.y=m->s2.pos_button_windowed.y+m->f.y;
		
			m->s2.pos_button_back.x=m->s2.pos_button_back.x+m->f.x;
			m->s2.pos_button_back.y=m->s2.pos_button_back.y+m->f.y;

			m->s.pos_settings.x=m->s.pos_settings.x+m->f.x;
			m->s.pos_settings.y=m->s.pos_settings.y+m->f.y;

			m->pos_credit.x=m->pos_credit.x+m->f.x;
			m->pos_credit.y=m->pos_credit.y+m->f.y;

			m->pos_button_play.x=m->pos_button_play.x+m->f.x;
			m->pos_button_play.y=m->pos_button_play.y+m->f.y;

			m->pos_button_exit.x=m->pos_button_exit.x+m->f.x;
			m->pos_button_exit.y=m->pos_button_exit.y+m->f.y;

			m->pos_button_credit.x=m->pos_button_credit.x+m->f.x;
			m->pos_button_credit.y=m->pos_button_credit.y+m->f.y;

			m->pos_button_settings.x=m->pos_button_settings.x+m->f.x;
			m->pos_button_settings.y=m->pos_button_settings.y+m->f.y;

			m->s2.pos_curseurvol.x=m->s2.pos_curseurvol.x+m->f.x;
			m->s2.pos_curseurvol.x=588;
		}
}


void Mise_a_jour_menu(menu *m,input *inp,int *continuer,SDL_Surface* screen)
{
	if(m->menu==0)
	{
	if(inp->keys.down==1)
		{
			m->soundcontrol=0;
			if(m->arrowpos<4)
				{m->arrowpos++;
				SDL_Delay(200);}
			else
				{m->arrowpos=1;
				SDL_Delay(200);}
		}
	if(inp->keys.up==1)
		{
			m->soundcontrol=0;
			if(m->arrowpos>1)
				{m->arrowpos--;
				SDL_Delay(200);}
			else
				{m->arrowpos=4;
				SDL_Delay(200);}
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_play.x,m->pos_button_play.x+m->pos_button_play.w,m->pos_button_play.y,m->pos_button_play.y+m->pos_button_play.h)==1)
		{
			m->buttonchoix=1;
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_settings.x,m->pos_button_settings.x+m->pos_button_settings.w,m->pos_button_settings.y,m->pos_button_settings.y+m->pos_button_settings.h)==1)
		{
			m->buttonchoix=2;
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_credit.x,m->pos_button_credit.x+m->pos_button_credit.w,m->pos_button_credit.y,m->pos_button_credit.y+m->pos_button_credit.h)==1)
		{
			m->buttonchoix=3;
		}
	if(pos_mouse_sans_click(*inp,m->pos_button_exit.x,m->pos_button_exit.x+m->pos_button_exit.w,m->pos_button_exit.y,m->pos_button_exit.y+m->pos_button_exit.h)==1)
		{
			m->buttonchoix=4;
		}
	if(m->buttonchoix>0)
		{
			m->arrowpos=0;
		}
	if((m->buttonchoix>0)&&(m->affonetime==0))
		{
			m->affonetime=1;
			m->soundcontrol=0;
		}
	else
	if(m->buttonchoix==0)
			m->affonetime=0;

	if((pos_mouse(*inp,m->pos_button_play.x,m->pos_button_play.x+m->pos_button_play.w,m->pos_button_play.y,m->pos_button_play.y+m->pos_button_play.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==1))
		{
			inp->mouse.click=0;
			m->p.affich_Load_multi_onetime=0;
			m->menu=1;
		}
	if((pos_mouse(*inp,m->pos_button_settings.x,m->pos_button_settings.x+m->pos_button_settings.w,m->pos_button_settings.y,m->pos_button_settings.y+m->pos_button_settings.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==2))
		{
			inp->mouse.click=0;
			m->menu=2;
		}
	if((pos_mouse(*inp,m->pos_button_credit.x,m->pos_button_credit.x+m->pos_button_credit.w,m->pos_button_credit.y,m->pos_button_credit.y+m->pos_button_credit.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==3))
		{
			inp->mouse.click=0;
			m->menu=3;
		}
	if((pos_mouse(*inp,m->pos_button_exit.x,m->pos_button_exit.x+m->pos_button_exit.w,m->pos_button_exit.y,m->pos_button_exit.y+m->pos_button_exit.h)==1)||(inp->keys.enter==1)&&(m->arrowpos==4))
		*continuer=0;
	
	}	
	if(m->menu==1)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=0;
				m->affichbackmenuonetime=0;
				SDL_Delay(500);}
			m->buttonchoix=0;
			m->affonetime=1;
			menuLoad(m,inp);//here
				
		}
	if(m->menu==2)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=0;
				m->affichbackmenuonetime=0;}
			m->buttonchoix=0;
			m->affonetime=1;
			m->s.testvol=-1;
			Volume(m,*inp);
			fullscreen_windowed(m,*inp,screen);
		}
	if(m->menu==3)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=0;
				m->affichbackmenuonetime=0;}
			m->buttonchoix=0;
			m->affonetime=1;
		}
	if(m->menu==5)
		{
			if((inp->keys.escape==1)||(pos_mouse(*inp,m->s2.pos_button_back.x,m->s2.pos_button_back.x+m->s2.pos_button_back.w,m->s2.pos_button_back.y,m->s2.pos_button_back.y+m->s2.pos_button_back.h)==1))
				{m->menu=1;
				m->p.affich_Load_multi_onetime=0;
				SDL_Delay(500);
				}
			menu_multiplayer(m,inp);//here		
		}
}

//free
void free_Menu(menu *m)
{
	int i;
	SDL_FreeSurface(m->ouverture_texte);
	SDL_FreeSurface(m->ouverture_back);
	for(i=0;i<4;i++)
	{
		SDL_FreeSurface(m->menu_back[i]);
	}

	SDL_FreeSurface(m->button_play_on);
	SDL_FreeSurface(m->button_play_off);
	SDL_FreeSurface(m->button_exit_on);
	SDL_FreeSurface(m->button_exit_off);
	SDL_FreeSurface(m->button_credit_on);
	SDL_FreeSurface(m->button_credit_off);
	SDL_FreeSurface(m->button_settings_on);
	SDL_FreeSurface(m->button_settings_off);
	SDL_FreeSurface(m->s.img_soundminus);
	SDL_FreeSurface(m->s.img_soundplus);
	SDL_FreeSurface(m->s.img_soundon);
	SDL_FreeSurface(m->s.img_soundoff);
	SDL_FreeSurface(m->s2.img_curseurvol);
	SDL_FreeSurface(m->s2.button_fullscreenon);
	SDL_FreeSurface(m->s2.button_windowedon);
	SDL_FreeSurface(m->s2.button_fullscreenoff);
	SDL_FreeSurface(m->s2.button_windowedoff);
	SDL_FreeSurface(m->s2.button_back);
	SDL_FreeSurface(m->c.texte_credit1);
	SDL_FreeSurface(m->c.texte_credit2);
	SDL_FreeSurface(m->c.texte_credit3);
	SDL_FreeSurface(m->c.texte_credit4);
	SDL_FreeSurface(m->c.texte_credit5);
	SDL_FreeSurface(m->c.texte_credit6);
	SDL_FreeSurface(m->f.fullscreen_back);
	SDL_FreeSurface(m->p.multi_back);
	SDL_FreeSurface(m->p.Load_back);//here
	Mix_FreeChunk(m->sound);
}



// entite
//1



void initEnnemi(Ennemi *e)
{
e->enem[0] = IMG_Load("8.png");
e->enem[1] = IMG_Load("9.png");
e->enem[2] = IMG_Load("10.png");
e->enem[3] = IMG_Load("11.png");
e->enem[4] = IMG_Load("12.png");
e->enem[5] = IMG_Load("13.png");
e->enem[6] = IMG_Load("14.png");
e->enem[7] = IMG_Load("15.png");
e->enem[8] = IMG_Load("1.png");
e->enem[9] = IMG_Load("2.png");
e->enem[10] = IMG_Load("3.png");
e->enem[11] = IMG_Load("4.png");
e->enem[12] = IMG_Load("5.png");
e->enem[13] = IMG_Load("6.png");
e->enem[14] = IMG_Load("7.png");
e->enem[15] = IMG_Load("16.png");
e->enem[16] = IMG_Load("17.png");
e->pos.x=300;
e->pos.y=400;
e->pos.h=0;
e->pos.w=0;




e->d=0;
e->num=0;

}

void afficherEnnemi(Ennemi e, SDL_Surface *screen)
{
if (e.pos.x>=0)
{
SDL_BlitSurface(e.enem[e.num],NULL,screen,&e.pos);
SDL_Flip(screen);}
}




void animerEnnemi( Ennemi * e,SDL_Surface *screen)
{
SDL_Delay(200);

SDL_Flip(screen);
e->num ++;
 if (e->num==16)
{ e->num=0;}
     //else e->num ++;

  }
/*
void deplacer( Ennemi * e)
{
int posmax=700;
int posmin=150;
     if (e->pos.x <= posmin)
          e->d=1;

     if (e->pos.x >= posmax)
          e->d=0;


     if (e->d== 1)
       e->pos.x=e->pos.x+50;
     else 
       e->pos.x=e->pos.x-50;



}
*/
void deplacer( Ennemi * e)
{
int posmax=650;
int posmin=300;
 if (e->pos.x > posmax)
    {
        e->d=1;
    }
    if (e->pos.x < posmin)
    {
        e->d=0;
    }
if (e->d==0)
    {
        e->pos.x += 50;
    }else if (e->d==1)
    {
        e->pos.x -= 50;
    }

     } 

int collisionBB( Personne p, Ennemi e)
{
int Collision;
if( (p.pos.x + p.pos.w < e.pos.x ) 
   ||(p.pos.x>  e.pos.x + e.pos.w) 
    ||(p.pos.y + p.pos.h< e.pos.y) ||
       (p.pos.y>  e.pos.y + e.pos.h ) )
            Collision = 0 ;       // pas de collision
else
            Collision = 1;
return Collision;
}

/*
int collisionBB( SDL_Rect positionpersonage, Ennemi e)
{
int Collision;
if( (positionpersonage.x + positionpersonage.w < e.pos. x) 
   ||(positionpersonage.x>  e.pos. x + e.pos. w) 
    ||(positionpersonage.y + positionpersonage.h< e.pos. y) ||
       (positionpersonage.y>  e.pos. y + e.pos. h ) )
            Collision = 0 ;       // pas de collision
else
            Collision = 1;
return Collision;
}*/
//////////////////////////////////////

//////////////////////////////////////
void affiche_back(back p, SDL_Surface* screen)
{
SDL_BlitSurface(p.img,NULL,screen,&p.pos1);

}


void liberer(back A)
{
		SDL_FreeSurface(A.img);
}
void initialiserbackg(back *A)
{

    A->img =SDL_LoadBMP("ennemi.bmp");
		if (A->img== NULL) {
			return ;
		}
	A->pos1.x=0;
	A->pos1.y=0;
	A->pos1.w=0;
	A->pos1.h=0;


}









void initialiser_score(vie *v){
    v->vie[0]=IMG_Load("health1.png");
    v->vie[1]=IMG_Load("health1.png");
    v->vie[2]=IMG_Load("health1.png");
    v->vie[3]=IMG_Load("health2.png");
    v->vie[4]=IMG_Load("health2.png");
     v->vie[5]=IMG_Load("health2.png");
    v->vie[6]=IMG_Load("health4.png");
   v->vie[7]=IMG_Load("health4.png");
    v->vie[8]=IMG_Load("health4.png");
v->vie[9]=IMG_Load("health4.png");


    v->pos.x=50;
    v->pos.y=150;
    v->pos_spr.x=0;
    v->pos_spr.y=0;
    v->pos_spr.h=50;
    v->pos_spr.w=200;

v->valeur_vie=0;
}
void afficher_vie(vie v,SDL_Surface* screen){
    SDL_BlitSurface(v.vie[v.valeur_vie],NULL,screen,&v.pos);
SDL_Flip(screen);
}






void deplacerIA(Ennemi *E,Personne p ) {
  if (((E->pos.x - p.pos.x) < 200) && ((E -> pos.x - p.pos.x) > 80))  
   {
    E -> d = 1; 
    E -> pos.x -= 10;
  } 
  else if (((E -> pos.x - p.pos.x) < -80) && ((E -> pos.x - p.pos.x) > -400))
   {
    E -> d = 0; 
    E -> pos.x += 10;
  } 
  else if (((E -> pos.x - p.pos.x) <= 80) && ((E -> pos.x - p.pos.x) >= 0)) 
  {
    E -> d =1;
  } 
  else if (((E -> pos.x - p.pos.x) <= 0) && ((E -> pos.x - p.pos.x) >= -80)) 
  {
    E -> d = 0;

  }
  else 
deplacer(E);

}


void initPerso(Personne *p)
{


p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;
p->time=0;
p->score=0;
p->dt=0;
p->num1=0;

p->num2=0;

p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("lf2.png");
p->image[0][1]=IMG_Load("rf1.png");
p->image[1][0]=IMG_Load("lf2_inverse.png");
p->image[1][1]=IMG_Load("rf_inverse.png");
p->image[2][0]=IMG_Load("attack_lf.png");
p->image[2][1]=IMG_Load("attac_rf.png");
p->image[3][0]=IMG_Load("attack_lf_inverse.png");
p->image[3][1]=IMG_Load("attac_lf_inv.png");
p->image[4][0]=IMG_Load("lf2.png");
p->image[4][1]=IMG_Load("lf2.png");
p->image[5][0]=IMG_Load("rf_inverse.png");
p->image[5][1]=IMG_Load("rf_inverse.png");
p->up=0;
p->nump=0;
initialiser_score(&(p->v));

}
void initPerso2(Personne *p)
{

p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;

p->dt=0;
p->num1=0;

p->num2=0;

p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("lf21.png");
p->image[0][1]=IMG_Load("rf11.png");
p->image[1][0]=IMG_Load("lf2_inverse1.png");
p->image[1][1]=IMG_Load("rf_inverse1.png");
p->image[2][0]=IMG_Load("attack_lf1.png");
p->image[2][1]=IMG_Load("attac_rf1.png");
p->image[3][0]=IMG_Load("attack_lf_inverse1.png");
p->image[3][1]=IMG_Load("attac_lf_inv1.png");
p->image[4][0]=IMG_Load("lf21.png");
p->image[4][1]=IMG_Load("lf21.png");
p->image[5][0]=IMG_Load("rf_inverse1.png");
p->image[5][1]=IMG_Load("rf_inverse1.png");
p->up=0;
p->nump=0;


}

void afficherPerso(Personne *p, SDL_Surface *screen)
{
SDL_Rect b;

b.x=0;
b.y=0;

//SDL_BlitSurface(p->vimg[p->vie],NULL,screen,&p->posvie);
        SDL_BlitSurface(p->image[p->dt][p->nump],NULL,screen,&p->pos);

afficher_vie( p->v,screen);

        
SDL_Flip(screen);
}

void deplacerPerso(Personne*p,int dt)
{
switch (dt)
{
case 0: 
p->pos.x+=50;


break;
case 1:
p->pos.x-=50;
break;


}//fin switch
}//fin fonction
  



void animerPerso(Personne *p, SDL_Surface *screen)
{

SDL_Rect b;
b.x=0;
b.y=0;

p->nump++;
 
if(p->nump>1)
p->nump=0;  

SDL_Flip(screen);
}

void saut (Personne* p) {
    if (p->pos.y == p->ground)
    {
       p->vs=-50;
       p->up=1;
    }
    
}





void freePerso(Personne *p)
{
SDL_FreeSurface(p->background);

SDL_FreeSurface(p->right[0]);
SDL_FreeSurface(p->right[1]);
SDL_FreeSurface(p->left[0]);
SDL_FreeSurface(p->left[1]);
SDL_FreeSurface(p->right[0]);

SDL_FreeSurface(p->attack[0]);
SDL_FreeSurface(p->attack[1]);

}











