#include "menu.h"
#include "input.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>


#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

#define SCREEN_W 1280
#define SCREEN_H 720

int main()
{ 	
	int continuer=1;
	menu gamemenu;
	input input_rep;
	SDL_Surface *screen1;

//Creation de la fenetre
	SDL_Init(SDL_INIT_VIDEO);
	SDL_WM_SetIcon(IMG_Load("RES/Logo/logo.bmp"),NULL);
	screen1=SDL_SetVideoMode(SCREEN_W,SCREEN_H,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
	SDL_WM_SetCaption("Assembly Of Eras", NULL);
	
//INIT
TTF_Init();
init_all_menu(&gamemenu,&input_rep);

//GAME LOOP
//init perso enemi
 Ennemi e;
	SDL_Surface *screen;
	int quitter = 0;
           vie v;
           int up;
	back Backg;
	SDL_Event event;
      int c;

        int play=0; // variable indiquant si le son bref doit etre joué ou non
	//atexit(SDL_Quit);
	// creation d'une fenetre
	screen= SDL_SetVideoMode(1280, 720, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
	
	
//Initialisation des variables
         initialiserbackg(&Backg);
initialiser_score(&v);
Personne p;
     initEnnemi(&e);
initPerso(&p);
        initialiser_score(&v);

//fin init perso enemi
	
while(continuer == 1)	
	{  switch (gamemenu.p.player_nbr)
          {
			case 0 :
			 affiche_Menu(&gamemenu,screen1);
			 get_input_rep(&continuer,&input_rep);
			 Mise_a_jour_menu(&gamemenu,&input_rep,&continuer,screen1);
			 SDL_Flip(screen1);break;
                        case 1:
                        // Game loop
while(!quitter) {
play=0;
//Display
//afficher_vie(&v,screen);
 
affiche_back(Backg,screen);
afficherPerso( &p,screen);
afficherEnnemi(e,screen);
animerEnnemi(&e,screen);


deplacerIA(&e,p ) ;
//deplacer(&e);



SDL_Flip(screen);




//Input
SDL_PollEvent(&event);
switch (event.type)
         {
        // exit if the window is closed
	case SDL_QUIT: quitter = 1;
        break;
        case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
       {
            case SDLK_ESCAPE: quitter =1;
            break;
            case SDLK_p: play=1;
            break;

       
        break;
           
        case SDLK_n:
up=1;
break;


case SDLK_a:
if (p.dt==1)
{p.dt=3;

animerPerso(&p,screen);}
else
{if (p.dt==0)
{p.dt=2;

animerPerso(&p,screen);}}
break;


            case SDLK_LEFT:
 		p.dt=1;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;



            case SDLK_s:
 		
                deplacerPerso(&p,p.dt);
                 deplacerPerso(&p,p.dt);
                   animerPerso(&p,screen);
                break;
            case SDLK_RIGHT:
             p.dt=0;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;
       
            }
break;
case SDL_KEYUP:
        switch(event.key.keysym.sym)
    {
    

    

    case SDLK_n:
        up=0;
        break; 

    
    }
       			break;
      }
                    
        if (up==1) saut(&p);

p.pos.y = p.pos.y   + p.vs ;
p.vs = p.vs + 10 ;
if (p.pos.y>=p.ground)
{   
    p.pos.y=p.ground;
    p.vs=0;
    p.up=0;
}
    
//col


c=collisionBB(p,e);
if (c==1)
{
    p.v.valeur_vie++;}
if(p.v.valeur_vie==8)
p.v.valeur_vie=1;


	}


                          
			break;
                        case 2:
			
			 printf("%d \n",gamemenu.p.player_nbr);
			 continuer=0;
			break;
	}
}

//FREE

free_Menu(&gamemenu);
atexit(SDL_Quit);
TTF_Quit();
SDL_Quit();


return 0 ;
}

