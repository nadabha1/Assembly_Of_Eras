#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include <string.h>




/**
* @struct clavier
* @brief struct for Keyboard
*/
typedef struct
{
	int i,k,l,o,m,a,b,c,d,e,f,g,h,j,n,p,q,r,s,t,u,v,w,x,y,z;		/*!< Letters*/
	int up,down,left,right;							/*!< Arrows*/
	int enter,escape,backspace,space,tab,lctrl,rctrl,rshift,lshift;		/*!< Symbols*/
	int n0,n1,n2,n3,n4,n5,n6,n7,n8,n9;					/*!< Numbers*/
}clavier;

/**
* @struct souris
* @brief struct for Mouse
*/
typedef struct
{
	int x,y,click;								/*!< Mouse Position and State*/
}souris;

/**
* @struct input
* @brief struct for Input
*/
typedef struct
{
	clavier keys;								/*!< Keyboard*/
	souris mouse;								/*!< Mouse*/
}input;

void init_input(input *Input);
int pos_mouse(input input_rep,int x,int w,int y,int h);
void get_input_rep(int *continuer,input *inp);
int pos_mouse_sans_click(input input_rep,int x,int w,int y,int h);



#endif
