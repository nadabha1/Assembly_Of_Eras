/**
* @file input.c
* @brief Testing Program.
* @author Heythem Amara
* @version 1.0
* @date Apr 20, 2022
*
* Testing program for Input
*
*/
#include "input.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

//---------------------------------------mouse motion---------------------------

/**
* @brief Condition of Mouse Position.
* @param input_rep the Input
* @param x the X
* @param w the W
* @param y the Y
* @param h the H
* @return Nothing
*/
int pos_mouse(input input_rep,int x,int w,int y,int h)
{
	if((pos_mouse_sans_click(input_rep,x,w,y,h)==1)&&(input_rep.mouse.click==1))
	return 1;
	else
	return 0;
}

int pos_mouse_sans_click(input input_rep,int x,int w,int y,int h)
{
	if(( input_rep.mouse.x > x ) && (input_rep.mouse. x < w ) && ( input_rep.mouse.y > y ) && ( input_rep.mouse.y < h ))
	return 1;
	else
	return 0;
}

//-----------------------------------------INIT------------------------------------

/**
* @brief To initialize the Input .
* @param e the Input
* @return Nothing
*/
void init_input(input *Input)
{
//mouse
	Input->mouse.click=0;
//letters
	Input->keys.a=0;
	Input->keys.b=0;
	Input->keys.c=0;
	Input->keys.d=0;
	Input->keys.e=0;
	Input->keys.f=0;
	Input->keys.g=0;
	Input->keys.h=0;
	Input->keys.i=0;
	Input->keys.j=0;
	Input->keys.k=0;
	Input->keys.l=0;
	Input->keys.m=0;
	Input->keys.n=0;
	Input->keys.o=0;
	Input->keys.p=0;
	Input->keys.q=0;
	Input->keys.r=0;
	Input->keys.s=0;
	Input->keys.t=0;
	Input->keys.u=0;
	Input->keys.v=0;
	Input->keys.w=0;
	Input->keys.x=0;
	Input->keys.y=0;
	Input->keys.z=0;
//arrows
	Input->keys.up=0;
	Input->keys.down=0;
	Input->keys.right=0;
	Input->keys.left=0;
//symbols 
	Input->keys.enter=0;
	Input->keys.escape=0;
        Input->keys.backspace=0;
        Input->keys.space=0;
        Input->keys.tab=0;
        Input->keys.lctrl=0;
        Input->keys.rctrl=0;
        Input->keys.lshift=0;
        Input->keys.rshift=0;
//numbers
	Input->keys.n0=0;
	Input->keys.n1=0;
	Input->keys.n2=0;
	Input->keys.n3=0;
	Input->keys.n4=0;
	Input->keys.n5=0;
	Input->keys.n6=0;
	Input->keys.n7=0;
	Input->keys.n8=0;
	Input->keys.n9=0;

}

//--------------------------------------Get Input----------------------------------
/**
* @brief To Get the Input .
* @param Continuer an Int
* @return Nothing
*/
void get_input_rep(int *continuer,input *inp)
{
	SDL_Event event;
	//input inp;
	if(SDL_PollEvent(&event))
	{	//init_input(&inp);
		switch(event.type)
	 {
			case SDL_QUIT:
            			*continuer=0;
			case SDL_MOUSEMOTION:
				inp->mouse.x=event.motion.x;
        			inp->mouse.y=event.motion.y;
			break;
			
			case SDL_MOUSEBUTTONDOWN:
			if ((event.button.button==SDL_BUTTON_LEFT))
					{
						inp->mouse.click=1;
					}

			break;
			case SDL_MOUSEBUTTONUP:
			if ((event.button.button==SDL_BUTTON_LEFT))
					{
						inp->mouse.click=0;
					}
			break;
//---------------------
			case SDL_KEYDOWN:
		switch (event.key.keysym.sym)
              {
//letters
		case SDLK_a: 
          	{inp->keys.a=1;}
           	break;
		case SDLK_b: 
          	{inp->keys.b=1;}
           	break;
		case SDLK_c: 
          	{inp->keys.c=1;}
           	break;
		case SDLK_d: 
          	{inp->keys.d=1;}
           	break;
		case SDLK_e: 
          	{inp->keys.e=1;}
           	break;
		case SDLK_f: 
          	{inp->keys.f=1;}
           	break;
		case SDLK_g: 
          	{inp->keys.g=1;}
           	break;
		case SDLK_h: 
          	{inp->keys.h=1;}
           	break;
		case SDLK_i:
          	{inp->keys.i=1;}
           	break;
		case SDLK_j: 
          	{inp->keys.j=1;}
           	break;
		case SDLK_k: 
          	{inp->keys.k=1;}
           	break;
		case SDLK_l: 
          	{inp->keys.l=1;}
           	break;
	  	case SDLK_m: 
          	{inp->keys.m=1;}
        	break;
		case SDLK_n: 
          	{inp->keys.n=1;}
           	break;
		case SDLK_o: 
          	{inp->keys.o=1;}
           	break;
		case SDLK_p: 
          	{inp->keys.p=1;}
           	break;
		case SDLK_q: 
          	{inp->keys.q=1;}
           	break;
		case SDLK_r: 
          	{inp->keys.r=1;}
           	break;
		case SDLK_s: 
          	{inp->keys.s=1;}
           	break;
		case SDLK_t: 
          	{inp->keys.t=1;}
           	break;
		case SDLK_u: 
          	{inp->keys.u=1;}
           	break;
		case SDLK_v: 
          	{inp->keys.v=1;}
           	break;
		case SDLK_w: 
          	{inp->keys.w=1;}
           	break;
		case SDLK_x: 
          	{inp->keys.x=1;}
           	break;
		case SDLK_y: 
          	{inp->keys.y=1;}
           	break;
		case SDLK_z: 
          	{inp->keys.z=1;}
           	break;
//arrows
		case SDLK_DOWN: 
          	{inp->keys.down=1;}
           	break;
          	case SDLK_UP: 
          	{inp->keys.up=1;}
          	break;
		case SDLK_RIGHT: 
          	{inp->keys.right=1;}
          	break;
		case SDLK_LEFT: 
          	{inp->keys.left=1;}
          	break;
//symbols
		case SDLK_RETURN: 
          	{inp->keys.enter=1;}
           	break;
		case SDLK_ESCAPE: 
          	{inp->keys.escape=1;}
           	break;
		case SDLK_BACKSPACE: 
          	{inp->keys.backspace=1;}
           	break;
		case SDLK_SPACE: 
          	{inp->keys.space=1;}
           	break;
		case SDLK_TAB: 
          	{inp->keys.tab=1;}
           	break;
		case SDLK_LCTRL: 
          	{inp->keys.lctrl=1;}
           	break;
		case SDLK_RCTRL: 
          	{inp->keys.rctrl=1;}
           	break;
		case SDLK_LSHIFT: 
          	{inp->keys.lshift=1;}
           	break;
		case SDLK_RSHIFT: 
          	{inp->keys.rshift=1;}
           	break;

//numbers
		case SDLK_0: 
          	{inp->keys.n0=1;}
           	break;
		case SDLK_1: 
          	{inp->keys.n1=1;}
           	break;
		case SDLK_2: 
          	{inp->keys.n2=1;}
           	break;
		case SDLK_3: 
          	{inp->keys.n3=1;}
           	break;
		case SDLK_4: 
          	{inp->keys.n4=1;}
           	break;
		case SDLK_5: 
          	{inp->keys.n5=1;}
           	break;
		case SDLK_6: 
          	{inp->keys.n6=1;}
           	break;
		case SDLK_7: 
          	{inp->keys.n7=1;}
           	break;
		case SDLK_8: 
          	{inp->keys.n8=1;}
           	break;
		case SDLK_9: 
          	{inp->keys.n9=1;}
           	break;


}
break;
		case SDL_KEYUP:
		switch (event.key.keysym.sym)
              {
//letters
		case SDLK_a: 
          	{inp->keys.a=0;}
           	break;
		case SDLK_b: 
          	{inp->keys.b=0;}
           	break;
		case SDLK_c: 
          	{inp->keys.c=0;}
           	break;
		case SDLK_d: 
          	{inp->keys.d=0;}
           	break;
		case SDLK_e: 
          	{inp->keys.e=0;}
           	break;
		case SDLK_f: 
          	{inp->keys.f=0;}
           	break;
		case SDLK_g: 
          	{inp->keys.g=0;}
           	break;
		case SDLK_h: 
          	{inp->keys.h=0;}
           	break;
		case SDLK_i:
          	{inp->keys.i=0;}
           	break;
		case SDLK_j: 
          	{inp->keys.j=0;}
           	break;
		case SDLK_k: 
          	{inp->keys.k=0;}
           	break;
		case SDLK_l: 
          	{inp->keys.l=0;}
           	break;
	  	case SDLK_m: 
          	{inp->keys.m=0;}
        	break;
		case SDLK_n: 
          	{inp->keys.n=0;}
           	break;
		case SDLK_o: 
          	{inp->keys.o=0;}
           	break;
		case SDLK_p: 
          	{inp->keys.p=0;}
           	break;
		case SDLK_q: 
          	{inp->keys.q=0;}
           	break;
		case SDLK_r: 
          	{inp->keys.r=0;}
           	break;
		case SDLK_s: 
          	{inp->keys.s=0;}
           	break;
		case SDLK_t: 
          	{inp->keys.t=0;}
           	break;
		case SDLK_u: 
          	{inp->keys.u=0;}
           	break;
		case SDLK_v: 
          	{inp->keys.v=0;}
           	break;
		case SDLK_w: 
          	{inp->keys.w=0;}
           	break;
		case SDLK_x: 
          	{inp->keys.x=0;}
           	break;
		case SDLK_y: 
          	{inp->keys.y=0;}
           	break;
		case SDLK_z: 
          	{inp->keys.z=0;}
           	break;
//arrows
		case SDLK_DOWN: 
          	{inp->keys.down=0;}
           	break;
          	case SDLK_UP: 
          	{inp->keys.up=0;}
          	break;
		case SDLK_RIGHT: 
          	{inp->keys.right=0;}
          	break;
		case SDLK_LEFT: 
          	{inp->keys.left=0;}
          	break;
//symbols
		case SDLK_RETURN: 
          	{inp->keys.enter=0;}
           	break;
		case SDLK_ESCAPE: 
          	{inp->keys.escape=0;}
           	break;
		case SDLK_BACKSPACE: 
          	{inp->keys.backspace=0;}
           	break;
		case SDLK_SPACE: 
          	{inp->keys.space=0;}
           	break;
		case SDLK_TAB: 
          	{inp->keys.tab=0;}
           	break;
		case SDLK_LCTRL: 
          	{inp->keys.lctrl=0;}
           	break;
		case SDLK_RCTRL: 
          	{inp->keys.rctrl=0;}
           	break;
		case SDLK_LSHIFT: 
          	{inp->keys.lshift=0;}
           	break;
		case SDLK_RSHIFT: 
          	{inp->keys.rshift=0;}
           	break;

//numbers
		case SDLK_0: 
          	{inp->keys.n0=0;}
           	break;
		case SDLK_1: 
          	{inp->keys.n1=0;}
           	break;
		case SDLK_2: 
          	{inp->keys.n2=0;}
           	break;
		case SDLK_3: 
          	{inp->keys.n3=0;}
           	break;
		case SDLK_4: 
          	{inp->keys.n4=0;}
           	break;
		case SDLK_5: 
          	{inp->keys.n5=0;}
           	break;
		case SDLK_6: 
          	{inp->keys.n6=0;}
           	break;
		case SDLK_7: 
          	{inp->keys.n7=0;}
           	break;
		case SDLK_8: 
          	{inp->keys.n8=0;}
           	break;
		case SDLK_9: 
          	{inp->keys.n9=0;}
           	break;


}
break;}}


//return inp;
}




