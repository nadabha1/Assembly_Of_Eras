
//#include "perso.h"
#include "ES.h"
#include <SDL/SDL_mixer.h>

int main ( int argc, char** argv )
{
// initialisation texte, video et son
    
        SDL_Init( SDL_INIT_VIDEO| SDL_INIT_AUDIO ) ;
        Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024); //Initialisation de l'API Mixer
//Déclaration des variables
        Ennemi e;
	SDL_Surface *screen;
	int quitter = 0;
           vie v;
           int up;
	back Backg;
	SDL_Event event;
      int c;

        int play=0; // variable indiquant si le son bref doit etre joué ou non
	//atexit(SDL_Quit);
	// creation d'une fenetre
	screen = SDL_SetVideoMode(1280, 720, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
	if ( !screen ) {
		printf("Unable to set 600x300 video: %s\n", SDL_GetError());
		return 1;
	}
//Initialisation des variables
         initialiserbackg(&Backg);
initialiser_score(&v);
Personne p;
     initEnnemi(&e);
initPerso(&p);
        initialiser_score(&v);

// Game loop
	while(!quitter) {
play=0;
//Display
//afficher_vie(&v,screen);
affiche_back(Backg,screen);

deplacerIA(&e,p ) ;
//deplacer(&e);
animerEnnemi(&e,screen);
afficherEnnemi(e,screen);

afficherPerso( &p,screen);

afficher_vie(v,screen);
SDL_Flip(screen);




//Input
SDL_PollEvent(&event);
switch (event.type)
         {
        // exit if the window is closed
	case SDL_QUIT: quitter = 1;
        break;
        case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
       {
            case SDLK_ESCAPE: quitter =1;
            break;
            case SDLK_p: play=1;
            break;

       
        break;
           
        case SDLK_n:
up=1;
break;

case SDLK_a:
if (p.dt==1)
{p.dt=3;

animerPerso(&p,screen);}
else
{if (p.dt==0)
{p.dt=2;

animerPerso(&p,screen);}}
break;


            case SDLK_LEFT:
 		p.dt=1;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;



            case SDLK_s:
 		
                deplacerPerso(&p,p.dt);
                 deplacerPerso(&p,p.dt);
                   animerPerso(&p,screen);
                break;
            case SDLK_RIGHT:
             p.dt=0;
                deplacerPerso(&p,p.dt);
                 
                   animerPerso(&p,screen);
                break;
       
            }
break;
case SDL_KEYUP:
        switch(event.key.keysym.sym)
    {
    

    

    case SDLK_n:
        up=0;
        break; 

    
    }
       			break;
      }
                    
        if (up==1) saut(&p);

p.pos.y = p.pos.y   + p.vs ;
p.vs = p.vs + 10 ;
if (p.pos.y>=p.ground)
{   
    p.pos.y=p.ground;
    p.vs=0;
    p.up=0;
}
    
//col


c=collisionBB(p,e);
if (c==1)
{
    v.valeur_vie++;}



	}


// free Surfaces

	//liberer(Backg);
    freePerso(&p);
   

    
	return 0;
}

