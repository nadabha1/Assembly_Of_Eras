#include "menu.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

void sauvegarde(perso p,background b)
{

FILE *savefileperso;
FILE *savefilebackground;

savefileperso = fopen ("savefileperso.bin", "wb");
if(savefileperso!=NULL)
{
fwrite (&p, sizeof(perso), 1, savefileperso);
fclose (savefileperso);
}

savefilebackground = fopen ("savefilebackground.bin", "wb");
if (savefilebackground!=NULL)
{
fwrite (&b, sizeof(background), 1, savefilebackground);
fclose (savefilebackground);
}
}


void load(perso *p,background *b)
{//il faut charger les images perso après l'appel de cette fonction

FILE *loadfileperso;
FILE *loadfilebackground;

loadfileperso = fopen ("loadfileperso.bin", "rb");
if(loadfileperso!=NULL)
{
	fread(&(*p), sizeof(perso), 1, loadfileperso);
	fclose (loadfileperso);
}
loadfilebackground = fopen ("loadfilebackground.bin", "rb");
if (loadfilebackground!=NULL)
{
	fread(&(*b), sizeof(background), 1, loadfilebackground);
	fclose (loadfilebackground);
}
}
