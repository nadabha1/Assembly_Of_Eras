#ifndef FONCTION_H_INCLUDED
#include "input.h"
#define FONCTION_H_INCLUDED
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>

#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include <string.h>

typedef struct{
SDL_Rect pos;
int vie;
int score;
}perso;

typedef struct{
SDL_Rect pos;
SDL_Rect camera;
}background;

void save(perso p,background b);
void load(perso *p,background *b);


#endif
