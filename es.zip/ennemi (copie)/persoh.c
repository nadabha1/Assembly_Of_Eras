#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include "perso.h"
//

void initPerso(Personne *p)
{

p->vimg[0]=IMG_Load("3.png");
p->vimg[1]=IMG_Load("2.png");
p->vimg[2]=IMG_Load("1.png");
p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;
p->time=0;
p->score=0;
p->dt=0;
p->num1=0;
p->background=SDL_LoadBMP("nature.bmp");
p->num2=0;
p->vie=0;
p->vs=0;
 p->ground=275;

//
p->image[0][0]=IMG_Load("lf2.png");
p->image[0][1]=IMG_Load("rf1.png");
p->image[1][0]=IMG_Load("lf2_inverse.png");
p->image[1][1]=IMG_Load("rf_inverse.png");
p->image[2][0]=IMG_Load("attack_lf.png");
p->image[2][1]=IMG_Load("attac_rf.png");
p->image[3][0]=IMG_Load("attack_lf_inverse.png");
p->image[3][1]=IMG_Load("attac_lf_inv.png");
p->image[4][0]=IMG_Load("lf2.png");
p->image[4][1]=IMG_Load("lf2.png");
p->image[5][0]=IMG_Load("rf_inverse.png");
p->image[5][1]=IMG_Load("rf_inverse.png");
p->up=0;
p->nump=0;

}
void afficherPerso(Personne *p, SDL_Surface *screen)
{
SDL_Rect b;

b.x=0;
b.y=0;
//SDL_BlitSurface(p->background, NULL, screen,&b );
//SDL_BlitSurface(p->vimg[p->vie],NULL,screen,&p->posvie);
        SDL_BlitSurface(p->image[p->dt][p->nump],NULL,screen,&p->pos);


/*if (p->up==1)
{p->pos.y= 275;
p->dt=0;
p->nump=0;
SDL_BlitSurface(p->image[p->dt][p->nump],NULL,screen,&p->pos);
p->up=0;
}



*/
        
SDL_Flip(screen);
}

void deplacerPerso(Personne*p,int dt)
{
switch (dt)
{
case 0: 
p->pos.x+=50;


break;
case 1:
p->pos.x-=50;
break;


}//fin switch
}//fin fonction
  



void animerPerso(Personne *p, SDL_Surface *screen)
{

SDL_Rect b;
b.x=0;
b.y=0;

p->nump++;
 
if(p->nump>1)
p->nump=0;  

SDL_Flip(screen);
}

void saut (Personne* p) {
    if (p->pos.y == p->ground)
    {
       p->vs=-50;
       p->up=1;
    }
    
}
void attack(Personne *p,SDL_Surface *screen)
{SDL_Rect b;
b.x=0;
b.y=0;
if (p->dt==1)
{SDL_BlitSurface(p->background, NULL, screen, &b);
 SDL_BlitSurface(p->vimg[p->vie],NULL,screen,&p->posvie);

SDL_BlitSurface(p->attack[0],NULL,screen,&p->pos);
SDL_Flip(screen);}

else 
{SDL_BlitSurface(p->background, NULL, screen, &b);
 SDL_BlitSurface(p->vimg[p->vie],NULL,screen,&p->posvie);

SDL_BlitSurface(p->attack[1],NULL,screen,&p->pos);
SDL_Flip(screen);}





}




void freePerso(Personne *p)
{
SDL_FreeSurface(p->background);

SDL_FreeSurface(p->right[0]);
SDL_FreeSurface(p->right[1]);
SDL_FreeSurface(p->left[0]);
SDL_FreeSurface(p->left[1]);
SDL_FreeSurface(p->right[0]);
SDL_FreeSurface(p->vimg[0]);
SDL_FreeSurface(p->vimg[1]);
SDL_FreeSurface(p->vimg[2]);
SDL_FreeSurface(p->attack[0]);
SDL_FreeSurface(p->attack[1]);

}




void affichertemp (Uint32 *temps,SDL_Surface *screen,TTF_Font *police)
{

SDL_Surface *chrono = NULL;
SDL_Rect positionChrono;
SDL_Color couleur = {255,255,255};
int min=0,sec=0;
char texteChrono [40] = "";
positionChrono.x = 840;
positionChrono.y = 10;
(*temps)=SDL_GetTicks();
(*temps)/=1000;
min=((*temps)/60);
sec=(*temps) - (60*min);


sprintf(texteChrono,"%02d:%02d",min,sec);
SDL_FreeSurface(chrono);
chrono = TTF_RenderText_Solid(police,texteChrono,couleur);
SDL_BlitSurface(chrono,NULL,screen,&positionChrono);
//}

}

void initPerso2(Personne *p)
{
p->vimg[0]=IMG_Load("31.png");
p->vimg[1]=IMG_Load("21.png");
p->vimg[2]=IMG_Load("11.png");
p->posvie.x=620;
p->posvie.y=20;
p->pos.x=10;
p->pos.y=275;

p->dt=0;
p->num1=0;

p->num2=0;
p->vie=0;
p->vs=0;
 p->ground=275;


p->image[0][0]=IMG_Load("lf21.png");
p->image[0][1]=IMG_Load("rf11.png");
p->image[1][0]=IMG_Load("lf2_inverse1.png");
p->image[1][1]=IMG_Load("rf_inverse1.png");
p->image[2][0]=IMG_Load("attack_lf1.png");
p->image[2][1]=IMG_Load("attac_rf1.png");
p->image[3][0]=IMG_Load("attack_lf_inverse1.png");
p->image[3][1]=IMG_Load("attac_lf_inv1.png");
p->image[4][0]=IMG_Load("lf21.png");
p->image[4][1]=IMG_Load("lf21.png");
p->image[5][0]=IMG_Load("rf_inverse1.png");
p->image[5][1]=IMG_Load("rf_inverse1.png");
p->up=0;
p->nump=0;


}






