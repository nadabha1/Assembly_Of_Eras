#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "ES.h"
int main()
{int num=0;
    SDL_Surface *screen =NULL;
    SDL_Surface *image =NULL,*personage[2];
     SDL_Surface *vie=NULL;
    SDL_Rect positionecran,positionpersonage,posvie;
    char pause;
    int continuer =1,curseur=1;
 Ennemi e;
back Backg;
int col;
    SDL_Event event;
    Mix_Music *music; 
    Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);
    Mix_VolumeMusic(MIX_MAX_VOLUME / 2);
    music=Mix_LoadMUS("music.mp3");
    Mix_PlayMusic(music,-1);
   // image = SDL_LoadBMP("ennemi.png");
    //image = IMG_Load("backg1.jpg");
    vie=IMG_Load("vie.png");
   personage[0]=IMG_Load("1p.png");
     personage[1]=IMG_Load("7p.png");
    /*SDL_SetColorKey(personage, SDL_SRCCOLORKEY, SDL_MapRGB(personage->format, 255, 255, 255));*/
    positionecran.x=-10;
    positionecran.y=-10;
    posvie.x=620;
    posvie.y=-10;
    positionpersonage.x=10;
    positionpersonage.y=275;
       SDL_Init(SDL_INIT_VIDEO);

        ///////////////////////////////////////////////////////////////////////////
     initialiserbackg(&Backg);

     initEnnemi(&e);
////////////////////////////////////


/*SDL_BlitSurface(personage[0],NULL,ecran,&positionpersonage);*/
	screen = SDL_SetVideoMode(1280, 720, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    while (continuer)
    {
     SDL_WaitEvent(&event);
        //SDL_BlitSurface(image, NULL, screen, &positionecran);
        SDL_BlitSurface(personage[num],NULL,screen,&positionpersonage);
         
///////////////////////////////////////
affiche_back(Backg,screen);
animerEnnemi(&e,screen);
deplacer(&e);

afficherEnnemi(e,screen);
SDL_Flip(screen);
col=collisionBB(positionpersonage,e);
/////////////////////////////////
      //  SDL_BlitSurface(vie,NULL,ecran,&posvie);
        SDL_Flip(screen);
        switch (event.type)
        {
        case SDL_QUIT:
            continuer=0;
            break;
        case SDL_KEYDOWN:
            switch (event.key.keysym.sym)
            {
            case SDLK_ESCAPE:
                continuer=0;
                break;
        case SDLK_UP:
//SDL_BlitSurface(image, NULL, screen, &positionecran);
            SDL_BlitSurface(vie,NULL,screen,&posvie);
                positionpersonage.y=positionpersonage.y-100;
             SDL_BlitSurface(personage[1],NULL,screen,&positionpersonage);
        
                 positionpersonage.y=positionpersonage.y+100;
                 SDL_Flip(screen);
        break;

            case SDLK_RIGHT:
positionpersonage.x=positionpersonage.x+20;
num++;
 
if(num==1)
   {//SDL_BlitSurface(image, NULL, screen, &positionecran);
SDL_BlitSurface(vie,NULL,screen,&posvie);
SDL_BlitSurface(personage[1],NULL,screen,&positionpersonage);
                 SDL_Flip(screen);
/*SDL_BlitSurface(personage[1],NULL,ecran,&positionpersonage);*/
                
num=0;}
                     
                      else {//SDL_BlitSurface(image, NULL, screen, &positionecran);
                            SDL_BlitSurface(vie,NULL,screen,&posvie);
SDL_BlitSurface(personage[0],NULL,screen,&positionpersonage);
                                SDL_Flip(screen);
                
                  
                 /*SDL_BlitSurface(personage[0],NULL,ecran,&positionpersonage);*/
                 }
SDL_Flip(screen);
                break;
            case SDLK_LEFT:
                positionpersonage.x=positionpersonage.x-20;
                 SDL_Flip(screen);
                break;}
       			break;
       /* case SDL_MOUSEBUTTONUP:              
                   
           
                positionpersonage.x=event.button.x;
                    positionpersonage.y=event.button.y;
                //SDL_BlitSurface(personage,NULL,ecran,&positionpersonage);
                                     
                                
                    break;*/
                    
        }
    }

    SDL_FreeSurface(image);
    SDL_FreeSurface(personage[0]);
  SDL_FreeSurface(personage[1]);
 
    return 0;
}

