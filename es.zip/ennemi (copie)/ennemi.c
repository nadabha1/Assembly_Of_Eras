
#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "ES.h"









//1



void initEnnemi(Ennemi *e)
{
e->enem[1] = IMG_Load("8.png");
e->enem[2] = IMG_Load("9.png");
e->enem[3] = IMG_Load("10.png");
e->enem[4] = IMG_Load("11.png");
e->enem[5] = IMG_Load("12.png");
e->enem[6] = IMG_Load("13.png");
e->enem[7] = IMG_Load("14.png");
e->enem[8] = IMG_Load("15.png");
e->enem[9] = IMG_Load("1.png");
e->enem[10] = IMG_Load("2.png");
e->enem[11] = IMG_Load("3.png");
e->enem[12] = IMG_Load("4.png");
e->enem[13] = IMG_Load("5.png");
e->enem[14] = IMG_Load("6.png");
e->enem[15] = IMG_Load("7.png");
e->enem[16] = IMG_Load("16.png");
e->enem[17] = IMG_Load("17.png");
e->pos.x=300;
e->pos.y=400;
e->pos.h=0;
e->pos.w=0;




e->d=0;
e->num=0;

}

void afficherEnnemi(Ennemi e, SDL_Surface *screen)
{
if (e.pos.x>=0)
{
SDL_BlitSurface(e.enem[e.num],NULL,screen,&e.pos);
SDL_Flip(screen);}
}




void animerEnnemi( Ennemi * e,SDL_Surface *screen)
{
SDL_Delay(200);

SDL_Flip(screen);
e->num ++;
 if (e->num==17)
{ e->num=0;}
     //else e->num ++;

  }
/*
void deplacer( Ennemi * e)
{
int posmax=700;
int posmin=150;
     if (e->pos.x <= posmin)
          e->d=1;

     if (e->pos.x >= posmax)
          e->d=0;


     if (e->d== 1)
       e->pos.x=e->pos.x+50;
     else 
       e->pos.x=e->pos.x-50;



}
*/
void deplacer( Ennemi * e)
{
int posmax=650;
int posmin=300;
 if (e->pos.x > posmax)
    {
        e->d=1;
    }
    if (e->pos.x < posmin)
    {
        e->d=0;
    }
if (e->d==0)
    {
        e->pos.x += 50;
    }else if (e->d==1)
    {
        e->pos.x -= 50;
    }

     } 

int collisionBB( Personne p, Ennemi e)
{
int Collision;
if( (p.pos.x + p.pos.w < e.pos.x ) 
   ||(p.pos.x>  e.pos.x + e.pos.w) 
    ||(p.pos.y + p.pos.h< e.pos.y) ||
       (p.pos.y>  e.pos.y + e.pos.h ) )
            Collision = 0 ;       // pas de collision
else
            Collision = 1;
return Collision;
}

/*
int collisionBB( SDL_Rect positionpersonage, Ennemi e)
{
int Collision;
if( (positionpersonage.x + positionpersonage.w < e.pos. x) 
   ||(positionpersonage.x>  e.pos. x + e.pos. w) 
    ||(positionpersonage.y + positionpersonage.h< e.pos. y) ||
       (positionpersonage.y>  e.pos. y + e.pos. h ) )
            Collision = 0 ;       // pas de collision
else
            Collision = 1;
return Collision;
}*/
//////////////////////////////////////

//////////////////////////////////////
void affiche_back(back p, SDL_Surface* screen)
{
SDL_BlitSurface(p.img,NULL,screen,&p.pos1);
}


void liberer(back A)
{
		SDL_FreeSurface(A.img);
}
void initialiserbackg(back *A)
{

    A->img =SDL_LoadBMP("ennemi.bmp");
		if (A->img== NULL) {
			return ;
		}
	A->pos1.x=0;
	A->pos1.y=0;
	A->pos1.w=0;
	A->pos1.h=0;


}









void initialiser_score(vie *v){
    v->vie[1]=IMG_Load("health1.png");
    v->vie[4]=IMG_Load("health2.png");
    v->vie[6]=IMG_Load("health3.png");
    v->vie[8]=IMG_Load("health4.png");

    v->pos.x=50;
    v->pos.y=150;
    v->pos_spr.x=0;
    v->pos_spr.y=0;
    v->pos_spr.h=50;
    v->pos_spr.w=200;

v->valeur_vie=1;
}

void afficher_vie(vie v,SDL_Surface* screen){
    SDL_BlitSurface(v.vie[v.valeur_vie],NULL,screen,&v.pos);
SDL_Flip(screen);
}






void deplacerIA(Ennemi *E,Personne p ) {
  if (((E->pos.x - p.pos.x) < 200) && ((E -> pos.x - p.pos.x) > 80))  
   {
    E -> d = 1; 
    E -> pos.x -= 10;
  } 
  else if (((E -> pos.x - p.pos.x) < -80) && ((E -> pos.x - p.pos.x) > -400))
   {
    E -> d = 0; 
    E -> pos.x += 10;
  } 
  else if (((E -> pos.x - p.pos.x) <= 80) && ((E -> pos.x - p.pos.x) >= 0)) 
  {
    E -> d =1;
  } 
  else if (((E -> pos.x - p.pos.x) <= 0) && ((E -> pos.x - p.pos.x) >= -80)) 
  {
    E -> d = 0;

  }
  else 
deplacer(E);

}



