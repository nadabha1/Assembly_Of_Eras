/**
* @file background.c 
* @brief Testing Program .
* @author C Teams
* @version 0.1
* @date apr 24, 2022
*
* Testing program for background scrolling
*
*/
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <stdlib.h>
#include "background.h"
//#include "collision.h"
/**  
* @brief To initialize the background b .  
* @param b the background   
* @return Nothing  
*/

void initBackground(Background *b)
{
  b->imgBack1[0] = IMG_Load("0.png");
  b->posBack1.x = 0;
  b->posBack1.y = 0;
  b->scroll.x = 0;
  b->scroll.y = 0;
  b->scroll.w = 1600;
  b->scroll.h = 400;
}
/**  
* @brief To initialize the background b .  
* @param b the background   
* @return Nothing  
*/

void initialiserimg(Background *b)
{
  b->imgBack1[0] = IMG_Load("1.png");
  b->imgBack1[1] = IMG_Load("2.png");
  b->imgBack1[2] = IMG_Load("3.png");
  b->imgBack1[3] = IMG_Load("4.png");
  b->imgBack1[4] = IMG_Load("5.png");
  b->imgBack1[5] = IMG_Load("6.png");
  b->imgBack1[6] = IMG_Load("7.png");
  b->imgBack1[7] = IMG_Load("8.png");
}
/**  
* @brief To show the background b .  
* @param scren the screen  
* @param b the background 
* @param i the int 
* @return Nothing  
*/
void afficherBack(Background b, SDL_Surface *ecran , int i )
{

  SDL_BlitSurface(b.imgBack1[i], &(b.scroll), ecran, NULL);
}
/**  
* @brief To scroll the background b .  
* @param b the background 
* @param poshero the placement
* @param direction the int 
* @return Nothing  
*/
void scrollingBack(Background *b, SDL_Rect poshero, int direction)
{
  if (direction == 1) // droite
  {
    b->scroll.x = b->scroll.x+10;
    b->posBack1.x = b->posBack1.x +10;
    if (b->scroll.x <= 21)
      b->scroll.x = 100;
    printf("\nscroll right abcisse cam: %d abcisse bg %d\n", b->scroll.x, b->posBack1.x);
  }
  else if (direction == 2) // gauche
  {
    do
{

    b->scroll.x += 10;
    b->posBack1.x += 10;
    if (b->scroll.x <= 10)
      b->scroll.x = 40;

}while(direction==2);

    printf("\nscroll left abcisse cam: %d abcisse bg %d\n", b->scroll.x, b->posBack1.x);
  }
  else if (direction == 3) // up
  {
    b->scroll.y -= 10;
    b->posBack1.y -= 10;
    if (b->scroll.y <= 0)
      b->scroll.y = 0;
    printf("\nscroll up abcisse cam: %d abcisse bg %d\n", b->scroll.y, b->posBack1.y);
  }
  else if (direction == 4) // down in case
  {
    b->scroll.y += 10;
    b->posBack1.y += 10;
    if (b->scroll.y >= 0)
      b->scroll.y = 0;
    printf("\nscroll down abcisse cam: %d abcisse bg %d\n", b->scroll.y, b->posBack1.y);
  }
}
/**  
* @brief To detect the color .  
* @param pSurface the screen  
* @param x the int 
* @param y the int 
* @return color  
*/
SDL_Color GetPixel(SDL_Surface *pSurface, int x, int y)
{
  SDL_Color color;
  Uint32 col = 0;

  // determine position
  char *pPosition = (char *)pSurface->pixels;

  // offset by y
  pPosition += (pSurface->pitch * y);

  // offset by x
  pPosition += (pSurface->format->BytesPerPixel * x);

  // copy pixel data
  memcpy(&col, pPosition, pSurface->format->BytesPerPixel);

  // convert color
  SDL_GetRGB(col, pSurface->format, &color.r, &color.g, &color.b);
  return (color);
}
/**  
* @brief To detect the color .  
* @param calque the screen
* @param perso the personnage  
* @param posperso the position  
* @param decalage the int  
* @param d the int 
* @return int  
*/
int collision_Parfaite(SDL_Surface *calque, SDL_Surface *perso, SDL_Rect posperso, int decalage, int d)
{
  SDL_Color col;

  if (d == 1)
  {
    col = GetPixel(calque, posperso.x + perso->w + decalage, posperso.y + (perso->h / 2));
  }
  else if (d == 2)
  {
    col = GetPixel(calque, posperso.x + decalage, posperso.y + (perso->h / 2));
  }
  else if (d == 3)
  {
    col = GetPixel(calque, posperso.x + (perso->w / 2) + decalage, posperso.y);
  }
  else if (d == 4)
  {
    col = GetPixel(calque, posperso.x + (perso->w / 2) + decalage, posperso.y + perso->h);
  }

  printf("%d    %d   %d\n",col.r,col.b,col.g );

  if ((col.r == 0) && (col.b == 0) && (col.g == 0))
  {
    return 1;
  }
  else
  {
    return 0;
  }
}
