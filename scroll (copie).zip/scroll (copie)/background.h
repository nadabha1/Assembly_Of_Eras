#ifndef BACKGROUNG_H_INCLUDED
#define BACKGROUNG_H_INCLUDED
//#include "collision.h"
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
/**
* @struct background
* @brief struct for background 
*/

typedef struct 
{
  SDL_Surface *imgBack1[7];
  SDL_Rect posBack1;
  SDL_Rect scroll;
  
}Background;

void initBackground(Background *b);
void initialiserimg(Background *b) ;
void initnightmap(Background *b) ;
void afficherBack(Background b,SDL_Surface *ecran, int i );
void animateBack(Background *b) ;
void scrollingBack(Background *b,SDL_Rect poshero,int direction);
SDL_Color  GetPixel(SDL_Surface *pSurface,int x,int y) ;
int collision_Parfaite(SDL_Surface *calque, SDL_Surface *perso, SDL_Rect posperso, int decalage, int d) ;

#endif
