var indexSectionsWithContent =
{
  0: "abcgims",
  1: "b",
  2: "bm",
  3: "acgis"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

