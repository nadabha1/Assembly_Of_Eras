var searchData=
[
  ['initback',['initBack',['../background_8c.html#a0a4edc94e7b2a235f7297ed1185dabd7',1,'background.c']]],
  ['initimg',['initimg',['../background_8c.html#a4c56c56bd905d521ade9394decfc82a3',1,'background.c']]]
];
