#include "player.h"
#include "header.h"
#include "background.h"
entity init_entity(int x, int y)
{
    entity e;
    e.position.x = x;
    e.position.y = y;
    return e;
}
//moving the player faster with shift key
void Acceleration(player *player, int acceleration)
{
    player->vitesse += acceleration;
}
//animating the player
void Animation_Personnage(player *player)
{
    int direction;

    if(!player->air && !player->mouvement.up)
        player->frame++;

    if (player->mouvement.left)
    {
        if(player->frame <= 4 || player->frame >= 9)
            player->frame = 5;
        direction = 2;
    }
    if (player->mouvement.right )
    {
        if(player->frame >= 4)
            player->frame = 0;
        direction = 1;
    }

}

//moving the player
void Deplacer_player(int vitesse, player *player)
{
    player->e.position.x += vitesse;
    position_absolue += vitesse;
}
//initilazing the player 
void init_player(player *player)
{
    player->e = init_entity(100, player_Default_Y);
    player->e.sprite[0] = IMG_Load("mvt/r1.png");
    player->e.sprite[1] = IMG_Load("mvt/r2.png");
    player->e.sprite[2] = IMG_Load("mvt/r3.png");
    player->e.sprite[3] = IMG_Load("mvt/r4.png");
    player->e.sprite[4] = IMG_Load("mvt/flip.png");
    player->e.sprite[5] = IMG_Load("mvt/l1.png");
    player->e.sprite[6] = IMG_Load("mvt/l2.png");
    player->e.sprite[7] = IMG_Load("mvt/l3.png");
    player->e.sprite[8] = IMG_Load("mvt/l4.png");
    player->frame = 0;
    player->direction = 'r';
    player->mouvement.right = 0;
    player->mouvement.left = 0;
    player->mouvement.up = 0;
    player->air = 0;
    player->sol = 0;
    player->mouse_clicked = 0;
    player->vitesse = 20;
}
//jumping
void jump(SDL_Event event, player *player)
{
    if(player->frame != 9)
    {
        if(player->air && player->e.position.y > JumpLimit && !player->sol)
            player->e.position.y += Gravity;
        if(player->e.position.y <= JumpLimit )
            player->sol = 1;
        if(player->e.position.y < player_Default_Y && player->sol )
            player->e.position.y -= Gravity;
        if(player->e.position.y == player_Default_Y)
        {
            player->sol = 0;
            player->air = 0;
        }
    }
}

//displaying the player
void aff_player(player *player)
{
    SDL_BlitSurface(player->e.sprite[player->frame], NULL, ecran, &player->e.position);
}
//freeing the player
void free_player(player *player)
{
    int i;
    for(i = 0; i < 10; i++)
    {
        SDL_FreeSurface(player->e.sprite[i]);
    }
}

