#include "player.h"
#include "sdl.h"
#include "background.h"
#include "header.h"

//Fonction qui assure l'alternance entre scrolling et déplacement de player
void mouvement(SDL_Event event, Background *background, player *player)
{
    
    SDLKey key = event.key.keysym.sym;
    if((key == SDLK_UP || key == SDLK_LEFT || key == SDLK_RIGHT || (player->mouse_clicked )) )
    {
        
        Animation_Personnage(player);
       

        if (player->mouvement.left)
        {
            if(player->e.position.x >= 640 || background->pos1.x >= 0)
                Deplacer_player(-player->vitesse, player);

           else
                scrolling(background,2);
        }
        if (player->mouvement.right)
        {
            if(player->e.position.x <= 640 || background->pos1.x <= (1280 - 3150) + 20)
            {
                if(player->e.position.x + player->e.position.w < 1280 - (60))
                    Deplacer_player(player->vitesse, player);
            }
            else
                scrolling(background,1);
        }
    }
} 


//detecting keypresses
void doKeyDown(SDL_Event event, player *player)
{    
         //jump
    if ((event.key.keysym.sym == SDLK_UP || event.key.keysym.sym == SDLK_SPACE ))
    {
        
        
            player->mouvement.up = 1;
            player->air = 1;
        
    }
     //gauche
    if (event.key.keysym.sym == SDLK_LEFT)
    {
        player->mouvement.left = 1;
        player->mouvement.right = 0;
        player->mouse_clicked = 0;
    }
    //droite
    if (event.key.keysym.sym == SDLK_RIGHT )
    {
        player->mouvement.right = 1;
        player->mouvement.left = 0;
        player->mouse_clicked = 0;
    }
        if (event.key.keysym.sym == SDLK_LSHIFT)
    	{
            Acceleration(player, +15);
        }
    
}

//stopping the movment once the key is no longer being pressed
void doKeyUp(SDL_Event event, player *player)
{
    if ((event.key.keysym.sym == SDLK_UP || event.key.keysym.sym == SDLK_SPACE))
    {
        
            player->mouvement.up = 0;
    }

    if (event.key.keysym.sym == SDLK_LEFT)
    {
        player->mouvement.left = 0;
        player->frame = 5;
    }

    if (event.key.keysym.sym == SDLK_RIGHT)
    {
        player->mouvement.right = 0;
        player->frame = 0;
    }
    if (event.key.keysym.sym == SDLK_LSHIFT)
    	{
            player->vitesse -= 15;
        }
}

//moving with the mouse
void mouvement_mouse(player *player)
{
    if(player->mouse_clicked )
    {
        if(player->mouvement.right && player->target < player->e.position.x)
        {
            player->mouse_clicked = 0;
            player->mouvement.right = 0;
        }
        if(player->mouvement.left && player->target > player->e.position.x)
        {
            player->mouvement.left = 0;
            player->mouse_clicked = 0;
        }
    }
}

//managing user input
void getInput(SDL_Event event, int *continuer, Background *background, player *player)
{
    int i;
    SDL_PollEvent(&event);
    switch(event.type)
    {
    	//Quitting the game
    	case SDL_QUIT:
        	(*continuer) = 0;
        break;
        //getting player input
    	case SDL_KEYDOWN:
		doKeyDown(event, player);
		switch(event.key.keysym.sym)
        {
        case SDLK_ESCAPE:
            	(*continuer) = 0;
            break;
	//getting mouse input
         case SDL_MOUSEBUTTONUP:
		player->target = event.button.x;
		player->mouse_clicked = 1;
        if(player->target > player->e.position.x)
            player->mouvement.right = 1;
        else
            player->mouvement.left = 1;
        break;
    }
    //giving the function the parameters it needs
    mouvement_mouse(player);
    mouvement(event, background, player);
    jump(event, player);
}
}
