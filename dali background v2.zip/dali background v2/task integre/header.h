#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include "sdl.h"
typedef struct
{
    SDL_Surface *imageDeFond ;
    SDL_Rect positionFond;

}Life;

Life life;

int Game();
int MenuOp();
int MenuP();
Life init_life(char life_name[]);
void init_SDL();
void aff_life(Life life);
#endif // HEADER_H_INCLUDED
