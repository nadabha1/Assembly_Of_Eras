
#ifndef ES_H_INCLUDED
#define ES_H_INCLUDED
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
typedef struct
{
	SDL_Rect pos1;

	SDL_Surface * img;
}back;

void initialiserbackg(back *B);
void affiche_back(back B, SDL_Surface* screen);
void liberer(back B);


typedef struct 
{
	SDL_Rect pos;
	SDL_Surface* enem[17];
	
int d,num;
	
}Ennemi;
typedef struct 

{
SDL_Surface* background;  
SDL_Rect pos,posvie;
SDL_Surface *image[6][2]; 
int nump;
float vs;
int num1;//direction droit
int num2;//direction gauche
SDL_Surface* right[2];
SDL_Surface* left[2];
SDL_Surface* attack[2];
int time;
SDL_Surface *vimg[3];
int vie;
int score;

int dt;//direction
int accel;
int vitesse;
int up,ground;
}Personne;

SDL_Surface *personage[2];





void initEnnemi(Ennemi*e);
void afficherEnnemi(Ennemi e, SDL_Surface * screen);
void animerEnnemi( Ennemi * e,SDL_Surface *screen);
void deplacer( Ennemi * e);
int collisionBB( Personne p, Ennemi e);
//void deplacerIA( Ennemi * e, SDL_Rect posPerso);



typedef struct  vie
{
	SDL_Surface *vie[10];
	int valeur_vie;
	SDL_Rect pos_spr,pos;
}vie;






void initialiser_score(vie *v);
void update_score(vie *v);
void afficher_vie(vie v,SDL_Surface *screen);





void affichertemp (Uint32 *temps,SDL_Surface *screen,TTF_Font *police);

void initPerso2(Personne *p)
void initPerso(Personne *p);
void afficherPerso(Personne *p,SDL_Surface *screen);
void deplacerPerso(Personne*p,int dt);
void animerPerso(Personne *p, SDL_Surface *screen);
void saut(Personne *p);
void freePerso(Personne *p);
void deplacerIA(Ennemi * E,Personne p );
#endif // ES_H_INCLUDED



